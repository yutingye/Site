#include "parser.h"
#include <time.h>

clock_t finish1;
clock_t start;
clock_t finish;
shapes* target;
shapes* pS[50];
int nShape;
tiles* pT;

char* Tmark;
int nSol=0;
char* Smark;
int tRot;
int initM;
char** candi;
int nCan;
int nCanLength=20;

int total=0;

inline bool fitin(shapes* s, int n, int m)
{
	int i,j,p;
	i=0;
	while(s->data[0][i++]==' ');
	p=m-(i-1);
	if(p<0) return false;
	for(i=0;i<s->height;i++){
		for(j=0;j<s->width;j++){
			if(s->data[i][j]!=' ' && ((n+i)>=target->height || (p+j)>=target->width))
				return false;
			if(s->data[i][j]!=' ' && (Tmark[(n+i)*target->width+p+j]!=-1 || s->data[i][j]!=target->data[n+i][p+j]) )
				return false;
		}
	}
	return true;
}

inline bool CheckSol()
{
	int NUM = target->height*target->width;
	char* candidate[3];
	int i,j,numCan;

	memset(candidate,NULL,3*sizeof(char *));
	numCan=0;

	if(tRot == 1){
		if(Tmark[initM] == Tmark[(initM+1)*target->width-1]){
			candidate[numCan++] = new char[NUM];
			for(i=0;i<target->height;i++){
				for(j=0;j<target->width;j++)
					candidate[numCan-1][i*target->width+j]=Tmark[j*target->height+target->width-1-i];
			}
		}
		if (Tmark[initM] == Tmark[(target->height-1-initM)*target->width]){
			candidate[numCan++] = new char[NUM];
			for(i=0;i<target->height;i++){
				for(j=0;j<target->width;j++)
					candidate[numCan-1][i*target->width+j]=Tmark[(target->height-1-j)*target->width+i];
			}
		}
		if (Tmark[initM] == Tmark[target->height*target->width-initM-1]){
			candidate[numCan++] = new char[NUM];
			for(i=0;i<target->height;i++){
				for(j=0;j<target->width;j++)
					candidate[numCan-1][i*target->width+j]=Tmark[NUM-1-(i*target->width+j)];
			}
		}
	}

	else if(tRot == 2){
		if(Tmark[initM] == Tmark[target->height*target->width-1-initM]){
			candidate[numCan++] = new char[NUM];
			for(i=0;i<target->height;i++){
				for(j=0;j<target->width;j++)
					candidate[numCan-1][i*target->width+j]=Tmark[NUM-1-(i*target->width+j)];
			}
		}
	}

	bool flag=false;
	for(i=0;i<nCan;i++){
		for(j=0;j<numCan;j++){
			if(!memcmp(candidate[j],candi[i],NUM)){
				flag=true;
				break;
			}
		}
		if(flag)
			break;
	}
	
	for(i=0;i<numCan;i++)
		delete candidate[i];

	if(!flag){
		if(nCan==nCanLength){
			nCanLength+=20;
			char** temp = new char*[nCanLength];
			memcpy(temp,candi,nCan*sizeof(char*));
			delete []candi;
			candi=temp;
		}
		candi[nCan++] = new char[NUM];
		memcpy(candi[nCan-1],Tmark,NUM);
		return true;
	}
	else
		return false;

}

void dumpTmark()
{
	for(int i=0;i<target->height;i++){
		for(int j=0;j<target->width;j++){
			cout<<char(Tmark[i*target->width+j]+'A')<<' ';
		}
		cout<<endl;
	}
	cout<<endl;
}

void match(shapes* s,int n,int m, int index)
{
	if(fitin(s, n,m))
	{
		int i,j,p;
		i=0;
		while(s->data[0][i++]==' ');
		p=m-(i-1);
		if(tRot==1){
			if((initM>=n && initM<n+s->height) && p+s->width==target->width){
				if(s->data[initM-n][s->width-1]!=' ' && Tmark[initM]>index)
					return;
			}
			if((target->height-1-initM>=n && target->height-1-initM<n+s->height) && p==0){
				if(s->data[target->height-1-initM-n][0]!=' ' && Tmark[initM]>index)
					return;
			}
			if(n+s->height==target->height && (target->width-1-initM>=p && target->width-1-initM<p+s->width)){
				if(s->data[s->height-1][target->width-1-initM-p]!=' ' && Tmark[initM]>index)
					return;
			}
		}
		else if(tRot==2){
			if(n+s->height==target->height && (target->width-1-initM>=p && target->width-1-initM<p+s->width)){
				if(s->data[s->height-1][target->width-1-initM-p]!=' ' && Tmark[initM]>index)
					return;
			}
		}

		for(i=0;i<s->height;i++){
			for(j=0;j<s->width;j++){
				if(s->data[i][j]!=' ')
					Tmark[(n+i)*target->width+p+j]=index;
			}
		}	
		
//		dumpTmark();
		if(!total){
			bool isSol = CheckSol();
			if(isSol){
				nSol++;
				//dumpTmark();
				if(nSol==1)
					finish1 = clock();
			}
			for(i=0;i<s->height;i++){
				for(j=0;j<s->width;j++){
					if(s->data[i][j]!=' ')
						Tmark[(n+i)*target->width+p+j]=-1;
				}
			}		
			return;
		}

		for(j=m;j<target->width;j++){
			if(Tmark[n*target->width+j]==-1 && target->data[n][j]!=' ')
				break;
		}
		if(j<target->width)
			search(n,j);
		else{
			bool flag=0;
			for(i=n+1;i<target->height;i++){
				for(j=0;j<target->width && target->data[n][j]!=0;j++){
					if(Tmark[i*target->width+j]==-1 && target->data[i][j]!=' '){
						flag=1;
						break;
					}
				}
				if(flag) break;
			}
			if(flag) search(i,j);
			else{
				bool isSol = CheckSol();
				if(isSol){
					nSol++;
					//dumpTmark();
					if(nSol==1)
						finish1 = clock();
				}
				for(i=0;i<s->height;i++){
					for(j=0;j<s->width && s->data[i][j]!=0;j++){
						if(s->data[i][j]!=' ')
							Tmark[(n+i)*target->width+p+j]=-1;
					}
				}		
				return;
			}
		}
		for(i=0;i<s->height;i++){
			for(j=0;j<s->width && s->data[i][j]!=0;j++){
				if(s->data[i][j]!=' ')
					Tmark[(n+i)*target->width+p+j]=-1;
			}
		}
	} 
}

void search(int n, int m)
{
	static int times=1;
	for(int i=0; i<nShape; i++){
		if(pT[i].available>0){
			if(times==1)
				nCan=0;
			pT[i].available--;
			total++;
			times++;
			
			for(int j=0;j<pT[i].nRot;j++){
				match(pT[i].S[j], n, m, i);
			}
			
			times--;
			total--;
			pT[i].available++;
		}
	}
}

int main(int argc, char* argv[])
{
	FileParser(argv[1]);
	ShapeParser(target, pS, nShape);
	if(!preprocess(pT, target, pS, nShape, tRot, total))
	{
		cout<<"No solution."<<endl;
		return 0;
	}

//	dumpShapes(pT, target, pS, nShape);
	
	start = clock();
	Tmark = new char[target->width*target->height];
	memset(Tmark,-1,target->width*target->height);
	Smark = new char[nShape];
	memset(Smark,UNVISITED,nShape);
	candi = new char*[nCanLength];

	int i=0;
	while(target->data[0][i++]==' ');
	initM = i-1;
	search(0,initM);

	cout<<"nSol:"<<nSol<<endl;

	finish=clock();
	cout<<finish1-start<<", "<<(double)(finish1-start)/CLOCKS_PER_SEC<<endl
		<<finish-start<<", "<<(double)(finish-start)/CLOCKS_PER_SEC<<endl;

	delete []Tmark;
	delete []Smark;
	for( i=0;i<target->height;i++)
		delete []target->data[i];
	delete []target->data;
	for(i=0;i<nShape;i++){
		for(int j=0;j<pS[i]->height;j++)
			delete []pS[i]->data[j];
		delete []pS[i]->data;
	}
	for(i=0;i<nCan;i++)
		delete candi[i];
	delete []candi;
	
	return 0;
}