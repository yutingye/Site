#include "parser.h"

const int MAX_LENGTH = 1024;

char** theFile;
char* mark;
int nRow,nCol;

void FileParser(char* fname)
{
	ifstream file;
	file.open(fname,ios::nocreate);
	if(!file.fail()){
		char buf[MAX_LENGTH];
		int gcount=0;
		nRow=nCol=0;
		do{
			file.getline(buf,MAX_LENGTH);
			gcount = file.gcount();
			if(gcount>0)
				nRow++;
			if(gcount>nCol)
				nCol = gcount;
		}while(gcount>0);
		file.close();

		file.open(fname);
		theFile = new char*[nRow];
		for(int i=0;i<nRow;i++){
			theFile[i] = new char[nCol];
			memset(theFile[i],0,nCol);
			file.getline(theFile[i],MAX_LENGTH);
		}
		file.close();

		mark = new char[nRow*nCol];
		memset(mark,UNVISITED,nRow*nCol);

	}
	else
		exit(0);
}

void traverse(int n, int m, int& l, int& r, int& p, int& d, int& g)
{
	mark[n*nCol+m] = VISITED;
	g++;
	if(m-1>=0 && mark[n*nCol+m-1]==UNVISITED && theFile[n][m-1]!=' ' && theFile[n][m-1]!=0){
		l = l<m-1? l:m-1;
		traverse(n,m-1,l,r,p,d,g);
	}
	if(m+1<nCol && mark[n*nCol+m+1]==UNVISITED && theFile[n][m+1]!=' ' && theFile[n][m+1]!=0){
		r = r>m+1? r:m+1;
		traverse(n,m+1,l,r,p,d,g);
	}
	if(n-1>=0 && mark[(n-1)*nCol+m]==UNVISITED && theFile[n-1][m]!=' ' && theFile[n-1][m]!=0){
		p = p<n-1?p:n-1;
		traverse(n-1,m,l,r,p,d,g);
	}
	if(n+1<nRow && mark[(n+1)*nCol+m]==UNVISITED && theFile[n+1][m]!=' ' && theFile[n+1][m]!=0){
		d = d>n+1?d:n+1;
		traverse(n+1,m,l,r,p,d,g);
	}
}

void ShapeParser(shapes*& target, shapes** pS, int& nShape)
{		
	int left,right,up,down,grids;
	int maxGrids=0;
	int i,j;
	nShape=0;
	for(i=0; i<nRow; i++){
		for(j=0;j<nCol;j++){
			left=right=j;
			up=down=i;
			grids = 0;
			if(mark[i*nCol+j]==UNVISITED && theFile[i][j]!=' ' && theFile[i][j]!=0){
				traverse(i,j,left,right,up,down,grids);
				shapes* theShape=new shapes;
				theShape->nGrids = grids;
				theShape->height = down - up + 1;
				theShape->width = right - left +1;
				theShape->data = new char*[theShape->height];
				for(int t=up; t<=down; t++){
					theShape->data[t-up]=new char[theShape->width];
					memcpy(theShape->data[t-up],&theFile[t][left],theShape->width);
					for(int p=0;p<theShape->width;p++){
						if(theShape->data[t-up][p]==0)
							break;
					}
					if(p<theShape->width){
						for(int q=p;q<theShape->width;q++)
							theShape->data[t-up][q]=' ';
					}
				}
				pS[nShape++]=theShape;
				if(grids>maxGrids){
					maxGrids = grids;
					target = pS[nShape-1];
				}
			}
		}
	}
	for(i=0;i<nShape;i++){
		if(pS[i]==target){
			for(j=i;j<nShape-1;j++)
				pS[j]=pS[j+1];
		}
	}
	nShape--;
	delete []mark;
	for(i=0;i<nRow;i++)
		delete []theFile[i];
	delete []theFile;
}


bool equiv(shapes* d, shapes* s)
{
	if(d->nGrids!=s->nGrids || d->height!=s->height || d->width!=s->width)
		return false;
	int i,j;
	for(i=0;i<d->height;i++){
		for(j=0;j<d->width;j++){
			if(d->data[i][j]!=s->data[i][j])//when one is 0 and the other is ' '
				return false;
		}
	}
	return true;
}

void rotate90(shapes* d, shapes* s)
{
	int i,j;
	d->height = s->width;
	d->width = s->height;
	d->nGrids = s->nGrids;
	d->data = new char*[d->height];
	for(i=0;i<d->height;i++){
		d->data[i] = new char[d->width];
		for(j=0;j<d->width;j++){
			d->data[i][j] = s->data[s->height-1-j][i];
		}
	}
}


bool preprocess(tiles*& pT, shapes* target, shapes** pS, int& nShape, int& tRot, int& total)
{
	pT = new tiles[nShape];
	int i,j;
	int totalGrids=0;
	int n=0;
	bool flag,flag2;
	int nRot=1;
	shapes* S2;
	shapes* S3;
	shapes* S4;
	
	pT[n].available = 1;
	
	S2 = new shapes;
	rotate90(S2,pS[0]);
	if(!equiv(S2,pS[0]))
		nRot++;

	S3 = new shapes;
	rotate90(S3,S2);
	flag = equiv(S3,pS[0]);
	if(!flag){
		nRot+=2;
		S4 = new shapes;
		rotate90(S4,S3);
	}
	pT[n].S = new shapes*[nRot];
	pT[n].S[0] = pS[0];
	pT[n].nRot = nRot;
	switch(nRot){
	case 1:
		delete S2;
		delete S3;
		break;
	case 2:
		pT[n].S[1] = S2;
		delete S3;
		break;
	case 4:
		pT[n].S[1] = S2;
		pT[n].S[2] = S3;
		pT[n].S[3] = S4;
		break;
	}
	n++;
	totalGrids+=pS[0]->nGrids;
	for(i=1;i<nShape;i++)
	{
		totalGrids+=pS[i]->nGrids;
		for(j=0;j<n;j++)
		{
			for(int l=0;l<pT[j].nRot;l++)
			{
				flag2 = equiv(pT[j].S[l],pS[i]);
				if(flag2){
					pT[j].available++;
					break;
				}
			}
			if(flag2)
				break;
		}
		if(flag2)
			continue;

		nRot = 1;
		
		S2 = new shapes;
		rotate90(S2,pS[i]);
		if(!equiv(S2,pS[i]))
			nRot++;

		S3 = new shapes;
		rotate90(S3,S2);
		flag = equiv(S3,pS[i]);
		if(!flag){
			nRot++;
			S4 = new shapes;
			rotate90(S4,S3);
			nRot++;
		}
		pT[n].available = 1;
		pT[n].S = new shapes*[nRot];
		pT[n].S[0] = pS[i];
		pT[n].nRot = nRot;
		switch(nRot){
		case 1:
			delete S2;
			delete S3;
			break;
		case 2:
			pT[n].S[1] = S2;
			delete S3;
			break;
		case 4:
			pT[n].S[1] = S2;
			pT[n].S[2] = S3;
			pT[n].S[3] = S4;
			break;
		}
		n++;
	}
	if(totalGrids<target->nGrids)
		return false;

	total = nShape;
	nShape = n;

	tRot=1;
	S2 = new shapes;
	rotate90(S2,target);
	if(!equiv(S2,target))
		tRot++;

	S3 = new shapes;
	rotate90(S3,S2);
	flag = equiv(S3,target);
	if(!flag)
		tRot+=2;
	delete S2;
	delete S3;
	return true;
}

void dumpShapes(tiles* pT, shapes* target, shapes** pS, int nShape)
{
	int i,j,k;
	cout<<"target:"<<endl;
	for(j=0;j<target->height;j++)
		cout<<target->data[j]<<endl;
	cout<<endl;

	for(i=0;i<nShape;i++){
		cout<<"Shape "<<i<<", available "<<pT[i].available<<endl;
		for(k=0;k<pT[i].nRot;k++){
			for(j=0;j<pT[i].S[k]->height;j++){
				cout<<pT[i].S[k]->data[j]<<endl;
			}
			cout<<endl;
		}
		cout<<endl;
	}
}
