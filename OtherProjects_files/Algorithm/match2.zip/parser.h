#ifndef _PARSER_H
#define _PARSER_H

#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <stdlib.h>

struct shapes
{
	char** data;
	int width;
	int height;
	int nGrids;
};

struct tiles
{
	shapes** S;
	int available;
	int nRot;
};

enum {UNVISITED, VISITED};

void FileParser(char*);
void traverse(int, int, int&, int&, int&, int&, int&);
void ShapeParser(shapes*&, shapes**, int&);
void dumpShapes(tiles* , shapes*, shapes**, int);
void rotate90(shapes*, shapes* );
bool equiv(shapes*, shapes* );
bool preprocess(tiles*&, shapes*, shapes**, int&, int&, int&);

void search(int,int);
void match(shapes* ,int ,int, int);

#endif