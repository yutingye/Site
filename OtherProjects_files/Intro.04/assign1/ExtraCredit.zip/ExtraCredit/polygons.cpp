#include "polygons.h"
#include <math.h>

#ifndef MATH_PI
#define MATH_PI 3.1416
#endif 

float gXArray[6]={0,3.55,3.55,0,-3.55,-3.55};
float gYArray[6]={4.1,2.05,-2.05,-4.1,-2.05,2.05};

struct Image {
    unsigned long sizeX;
    unsigned long sizeY;
    unsigned char *pixels;
};

int LoadBMP(char *filename, Image *image)
{
    FILE *file;
    unsigned long size;        // size of the image in bytes.
    unsigned long i;           // standard counter.
    unsigned short int planes; // number of planes in image (must be 1) 
    unsigned short int bpp;    // number of bits per pixel (must be 24)
    char temp;                 // temporary color storage for bgr-rgb conversion.
    
    // The job of this code is to
    // load in a bitmap file. If the file doesn't exist NULL is sent back
    // meaning the texture couldn't be loaded. Before I start explaining the
    // code there are a few VERY important things you need to know about the
    // images you plan to use as textures. The image height and width MUST be a
    // power of 2. The width and height must be at least 64 pixels, and for
    // compatibility reasons, shouldn't be more than 256 pixels. If the image
    // you want to use is not 64, 128 or 256 pixels on the width or height,
    // resize it in an art program. There are ways around this limitation, but
    // for now we'll just stick to standard texture sizes. 
    
    // make sure the file is there.
    
    if ((file = fopen(filename, "rb"))==NULL) {
        printf("File Not Found : %s\n",filename);
        return 0;
    }
    
    // seek through the bmp header, up to the width/height:
    fseek(file, 18, SEEK_CUR);
    
    // No 100% errorchecking anymore!!!
    
    // read the width
    fread(&image->sizeX, sizeof(int), 1, file);
    printf("Width of %s: %lu\n", filename, image->sizeX);
    
    // read the height
    fread(&image->sizeY, sizeof(int), 1, file);
    printf("Height of %s: %lu\n", filename, image->sizeY);
    
    // calculate the size (assuming 24 bits or 3 bytes per pixel).
    size = image->sizeX * image->sizeY * 4;
    
    // read the planes
    fread(&planes, sizeof(short), 1, file);
    if (planes != 1) {
        printf("Planes from %s is not 1: %u\n", filename, planes);
        return 0;
    }
    
    // read the bpp
    fread(&bpp, sizeof(short), 1, file);
    if (bpp != 24) {
        printf("Bpp from %s is not 24: %u\n", filename, bpp);
        return 0;
    }
    
    // seek past the rest of the bitmap header.
    fseek(file, 24, SEEK_CUR);
    
    // read the data. 
    image->pixels = (unsigned char *) malloc(size);
    if (image->pixels == NULL) {
        printf("Error allocating memory for color-corrected image data");
        return 0;
    }
    
    for (i=0;i<size;i+=4) { // reverse all of the colors. (bgr -> rgb)
        if (fread(&image->pixels[i], 3, 1, file) != 1) {
            printf("Error reading image data from %s.\n", filename);
            return 0;
        }
        temp = image->pixels[i];
        image->pixels[i] = image->pixels[i+2];
        image->pixels[i+2] = temp;
        image->pixels[i+3] = 255;
    }
    
    // we're done.
    return 1;
}

// Load Bitmaps And Convert To Textures
unsigned int load_texture(char *filename)
{
    // Load Texture
    Image image_data;
    unsigned int   texture_num;

    // allocate space for texture
    if (!LoadBMP(filename, &image_data)) {
        exit(1);
    }
    
    // Create Texture   
    glGenTextures(1, &texture_num);
    // 2d texture (x and y size)
    glBindTexture(GL_TEXTURE_2D, texture_num);
    
    // scale linearly when image bigger than texture
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
    
    // scale linearly when image smalled than texture
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR); 
    
    // 2d texture, level of detail 0 (normal), 3 components 
    // (red, green, blue), x size from image, y size from image, 
    // border 0 (normal), rgb color data, unsigned byte data, and 
    // finally the data itself.
    
    glTexImage2D(GL_TEXTURE_2D, 0, 3, image_data.sizeX, image_data.sizeY, 0, 
        GL_RGBA, GL_UNSIGNED_BYTE, image_data.pixels);

    free(image_data.pixels);
    return texture_num;
}

Polygons::Polygons( int radius )
{
	mR=radius;
	mCenterX=25;
	mCenterY=30;
	bTexture=false;
	bAnim=false;
	for(int i=0;i<7;i++)
		mRotate[i]=0;
	mDisl=glGenLists(1); 
	BuildList();
}

void Polygons::BuildList()
{
	glNewList(mDisl,GL_COMPILE); 
	glBegin(GL_TRIANGLE_FAN);
	glTexCoord2f(0.5,0.5);
	glVertex2f(0,0);
	glTexCoord2f(0.25f,0.933f);
	glVertex2f(-mR,1.732*mR);
	glTexCoord2f(0,0.5f);
	glVertex2f(-2*mR,0);
	glTexCoord2f(0.25,0.067);
	glVertex2f(-mR,-1.732*mR);
	glTexCoord2f(0.75,0.067);
	glVertex2f(mR,-1.732*mR);
	glTexCoord2f(1,0.5);
	glVertex2f(2*mR,0);
	glTexCoord2f(0.75,0.933);
	glVertex2f(mR,1.732*mR);
	glTexCoord2f(0.25,0.933);
	glVertex2f(-mR,1.732*mR);
	glEnd();
	glEndList();
}

void Polygons::ToggleTexturing()
{
	bTexture=!bTexture;
	if(bTexture)
		glEnable(GL_TEXTURE_2D);
	else
		glDisable(GL_TEXTURE_2D);
}

void Polygons::Render() 
{
    glBindTexture(GL_TEXTURE_2D, mTexture);
	if(bAnim)
	{
		for(int i=0;i<7;i++)
			mRotate[i]+=.2;
	}
	glLoadIdentity();
	glTranslatef(mCenterX,mCenterY,0.f);
	glRotatef(mRotate[0],0,0,1.f);
	glCallList(mDisl);
	for(int i=0;i<6;i++)
	{
		glPushMatrix();
		glTranslatef(gXArray[i]*mR,gYArray[i]*mR,0.f);
		glRotatef(mRotate[i+1],0,0,1.f);
		glCallList(mDisl);
		glPopMatrix();
	}
}

void Polygons::WindowWidth( int w, int h )
{
	mWindWid=w;
	mWindHei=h;
}

void Polygons::Click( int x, int y )
{
	float posX,posY,B4Rx,B4Ry;
	float Angle = mRotate[0]*MATH_PI/180;
	float SINangle = sin(Angle);
	float COSangle = cos(Angle);
	B4Rx=x-mWindWid/2-mCenterX;
	B4Ry=mWindHei/2-y-mCenterY;

	posX=COSangle*B4Rx+SINangle*B4Ry;
	posY=-SINangle*B4Rx+COSangle*B4Ry;

	bRotate = false;
	bTranslate = false;
	bDrag = false;

	if(Check(posX,posY))
		mFocus=-1;
	else
	{
		float localX,localY;
		for(int i=0;i<6;i++)
		{
			localX = cos(mRotate[i+1]*MATH_PI/180)*(posX-gXArray[i]*mR)+sin(mRotate[i+1]*MATH_PI/180)*(posY-gYArray[i]*mR);
			localY = -sin(mRotate[i+1]*MATH_PI/180)*(posX-gXArray[i]*mR)+cos(mRotate[i+1]*MATH_PI/180)*(posY-gYArray[i]*mR);
			if(Check(localX,localY)){
				mFocus=i;
				break;
			}
		}
	}
	if(bRotate || bTranslate || bDrag)
	{
		mStartPosX=x;
		mStartPosY=y;
	}

}

void Polygons::Drag( int x, int y )
{
	if( bRotate == true){
		if(mFocus==-1)
			mRotate[0]+=180*(atan2((mWindHei/2-y-mCenterY),(x-mWindWid/2-mCenterX))-atan2((mWindHei/2-mStartPosY-mCenterY),(mStartPosX-mWindWid/2-mCenterX)))/MATH_PI;
		else{
			float posX,posY,B4Rx,B4Ry;
			float Angle = mRotate[0]*MATH_PI/180;
			float SINangle = sin(Angle);
			float COSangle = cos(Angle);
			B4Rx=x-mWindWid/2-mCenterX;
			B4Ry=mWindHei/2-y-mCenterY;

			posX=COSangle*B4Rx+SINangle*B4Ry;
			posY=-SINangle*B4Rx+COSangle*B4Ry;
			
			B4Rx=mStartPosX-mWindWid/2-mCenterX;
			B4Ry=mWindHei/2-mStartPosY-mCenterY;
			float SposX=COSangle*B4Rx+SINangle*B4Ry;
			float SposY=-SINangle*B4Rx+COSangle*B4Ry;

			mRotate[mFocus+1]+=180*(atan2(posY-gYArray[mFocus]*mR,posX-gXArray[mFocus]*mR)-atan2(SposY-gYArray[mFocus]*mR,SposX-gXArray[mFocus]*mR))/MATH_PI;
		}
	}
	if( bTranslate == true){
		mCenterX+=x-mStartPosX;
		mCenterY+=mStartPosY-y;
	}
	if( bDrag == true)
	{
		float posX,posY,B4Rx,B4Ry;
		float Angle = mRotate[0]*MATH_PI/180;
		float SINangle = sin(Angle);
		float COSangle = cos(Angle);
		B4Rx=x-mWindWid/2-mCenterX;
		B4Ry=mWindHei/2-y-mCenterY;

		float X1,X2,X3,max1,Max;

		if(mFocus==-1){
			posX=COSangle*B4Rx+SINangle*B4Ry;
			posY=-SINangle*B4Rx+COSangle*B4Ry;
			X1 = 1.732*posX/2+0.5*posY;
			X1=X1>=0?X1:-X1;
			X2 = posY>=0?posY:-posY;
			X3 = -1.732*posX/2+0.5*posY;
			X3=X3>=0?X3:-X3;
			max1 = X1>X2?X1:X2;
			Max = max1>X3?max1:X3;
			mR=Max/1.732;
		}

		else{
			posX=cos(mRotate[mFocus+1]*MATH_PI/180)*(COSangle*B4Rx+SINangle*B4Ry-gXArray[mFocus]*mR)+sin(mRotate[mFocus+1]*MATH_PI/180)*(-SINangle*B4Rx+COSangle*B4Ry-gYArray[mFocus]*mR);
			posY=-sin(mRotate[mFocus+1]*MATH_PI/180)*(COSangle*B4Rx+SINangle*B4Ry-gXArray[mFocus]*mR)+cos(mRotate[mFocus+1]*MATH_PI/180)*(-SINangle*B4Rx+COSangle*B4Ry-gYArray[mFocus]*mR);

			X1 = 1.732*posX/2+0.5*posY;
			X1=X1>=0?X1:-X1;
			X2 = posY>=0?posY:-posY;
			X3 = -1.732*posX/2+0.5*posY;
			X3=X3>=0?X3:-X3;
			max1 = X1>X2?X1:X2;
			Max = max1>X3?max1:X3;
			float tR=mR;
			mR=Max/1.732;
			
			float delta=4.1*(tR-mR);
			float tX=0;
			float tY=0;
			switch(mFocus)
			{
			case -1:
				break;
			case 0:
				tY+=delta;
				break;
			case 1:
				tX+=delta*1.732/2;
				tY+=delta/2;
				break;
			case 2:
				tX+=delta*1.732/2;
				tY-=delta/2;
				break;
			case 3:
				tY-=delta;
				break;
			case 4:
				tX-=delta*1.732/2;
				tY-=delta/2;
				break;
			case 5:
				tX-=delta*1.732/2;
				tY+=delta/2;
			}
			mCenterX+=cos(mRotate[0]*MATH_PI/180)*tX-sin(mRotate[0]*MATH_PI/180)*tY;
			mCenterY+=sin(mRotate[0]*MATH_PI/180)*tX+cos(mRotate[0]*MATH_PI/180)*tY;
		}
		BuildList();
	}	
	mStartPosX=x;
	mStartPosY=y;

}

bool Polygons::Check(float x, float y)
{
	if( ((abs(y-1.732*mR)<5) && ( (abs(x+mR)<5) || (abs(x-mR)<5) )) || ((abs(y)<5) && ( (abs(x-2*mR)<5) || (abs(x+2*mR)<5) )) || ((abs(y+1.732*mR)<5) && ( (abs(x+mR)<5) || (abs(x-mR)<5) )) )
	{
		bRotate=true;
		return true;
	}
	if( (abs(y-1.732*mR)<5 && x<mR && x>-mR) || (abs(y+1.732*mR)<5 && x<mR && x>-mR) || (x>-2*mR && x<-mR && (abs(y-1.732*(x+2*mR))<5 || abs(y+1.732*(x+2*mR))<5)) || (x<2*mR && x>mR && (abs(y-1.732*(x-2*mR))<5||abs(y+1.732*(x-2*mR))<5) ) )
	{
		bDrag=true;
		return true;
	}
	if( (x-y/1.732>-2*mR) && (x-y/1.732<2*mR) && (y>-1.732*mR) && (y<1.732*mR) && (x+y/1.732>-2*mR) && (x+y/1.732<2*mR) )
	{
		bTranslate=true;
		return true;
	}
	return false;
}

void Polygons::Animation()
{
	bAnim=!bAnim;
}