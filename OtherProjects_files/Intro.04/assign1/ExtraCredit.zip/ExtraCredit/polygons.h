#ifndef _POLYGONS_H
#define _POLYGONS_H

#include <iostream>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

class Polygons {
private:
	float mR;
	float mCenterX;
	float mCenterY;
	int mStartPosX;
	int mStartPosY;
	int mWindWid;
	int mWindHei;
	float mRotate[7];
	GLuint mDisl;
	int mFocus;
	bool bDrag;
	bool bTranslate;
	bool bRotate;
	bool bTexture;
	bool bAnim;
	void BuildList();
public:
	unsigned int mTexture;
	Polygons( int radius );
	void Render();
	void Click( int x, int y );
	void Drag( int x, int y );
	bool Check(float x, float y);
	void WindowWidth( int w, int h );
	void ToggleTexturing();
	void Animation();
};

#endif