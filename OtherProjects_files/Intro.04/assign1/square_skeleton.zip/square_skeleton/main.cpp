#include "square.h"

//using namespace std;

Square *theSquare;
extern unsigned int load_texture(char*);

void display( void )
{
	glClear( GL_COLOR_BUFFER_BIT );
	theSquare->Render();
	glutSwapBuffers();
}

void initgl(void)
{
	glClearColor( .3, .3, .3, 1 );
	theSquare->mTexture=load_texture("square.bmp");
}

void reshape( int w, int h )
{
	static int first = 1;
	if (first)
	{
		first = 0;
		initgl();
	}
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	
	glOrtho( -w/2, w/2-1, -h/2, h/2-1, -1, 1 );
	glViewport( 0, 0, w, h );

	glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix 
	glLoadIdentity(); // Reset The Modelview Matrix 

	theSquare->WindowWidth( w, h );
	glutPostRedisplay();
}

void keyboard( unsigned char key, int x, int y )
{
	if (key == 27) // ESC
	{
		exit(0);
	}
	if (key == 't' || key == 'T')
	{
		theSquare->ToggleTexturing();
	}
	
	glutPostRedisplay();
}

static bool doing_it = false;

void mouse( int button, int state, int x, int y )
{
	if (button == GLUT_LEFT && state == GLUT_DOWN)
	{
		theSquare->Click( x, y );
		doing_it = true;
	}
	else doing_it = false;
	glutPostRedisplay();
}

void motion( int x, int y )
{
	if (doing_it)
	{
		theSquare->Drag( x, y );
		glutPostRedisplay();
	}
}

void main (int argc, char *argv[]) {
	
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE );
	glutInitWindowSize( 500, 500 );
	
	glutCreateWindow( "Intro Graphics Assignment 0" );
	
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );
	glutKeyboardFunc( keyboard );
	glutMouseFunc( mouse );
	glutMotionFunc( motion );
	
	theSquare = new Square( 100 );
	
	glutMainLoop();
}
