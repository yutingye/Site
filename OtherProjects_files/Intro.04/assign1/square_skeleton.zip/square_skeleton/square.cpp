#include "square.h"
#include <math.h>

#ifndef MATH_PI
#define MATH_PI 3.1416
#endif 

struct Image {
    unsigned long sizeX;
    unsigned long sizeY;
    unsigned char *pixels;
};

int LoadBMP(char *filename, Image *image)
{
    FILE *file;
    unsigned long size;        // size of the image in bytes.
    unsigned long i;           // standard counter.
    unsigned short int planes; // number of planes in image (must be 1) 
    unsigned short int bpp;    // number of bits per pixel (must be 24)
    char temp;                 // temporary color storage for bgr-rgb conversion.
    
    // The job of this code is to
    // load in a bitmap file. If the file doesn't exist NULL is sent back
    // meaning the texture couldn't be loaded. Before I start explaining the
    // code there are a few VERY important things you need to know about the
    // images you plan to use as textures. The image height and width MUST be a
    // power of 2. The width and height must be at least 64 pixels, and for
    // compatibility reasons, shouldn't be more than 256 pixels. If the image
    // you want to use is not 64, 128 or 256 pixels on the width or height,
    // resize it in an art program. There are ways around this limitation, but
    // for now we'll just stick to standard texture sizes. 
    
    // make sure the file is there.
    
    if ((file = fopen(filename, "rb"))==NULL) {
        printf("File Not Found : %s\n",filename);
        return 0;
    }
    
    // seek through the bmp header, up to the width/height:
    fseek(file, 18, SEEK_CUR);
    
    // No 100% errorchecking anymore!!!
    
    // read the width
    fread(&image->sizeX, sizeof(int), 1, file);
    printf("Width of %s: %lu\n", filename, image->sizeX);
    
    // read the height
    fread(&image->sizeY, sizeof(int), 1, file);
    printf("Height of %s: %lu\n", filename, image->sizeY);
    
    // calculate the size (assuming 24 bits or 3 bytes per pixel).
    size = image->sizeX * image->sizeY * 4;
    
    // read the planes
    fread(&planes, sizeof(short), 1, file);
    if (planes != 1) {
        printf("Planes from %s is not 1: %u\n", filename, planes);
        return 0;
    }
    
    // read the bpp
    fread(&bpp, sizeof(short), 1, file);
    if (bpp != 24) {
        printf("Bpp from %s is not 24: %u\n", filename, bpp);
        return 0;
    }
    
    // seek past the rest of the bitmap header.
    fseek(file, 24, SEEK_CUR);
    
    // read the data. 
    image->pixels = (unsigned char *) malloc(size);
    if (image->pixels == NULL) {
        printf("Error allocating memory for color-corrected image data");
        return 0;
    }
    
    for (i=0;i<size;i+=4) { // reverse all of the colors. (bgr -> rgb)
        if (fread(&image->pixels[i], 3, 1, file) != 1) {
            printf("Error reading image data from %s.\n", filename);
            return 0;
        }
        temp = image->pixels[i];
        image->pixels[i] = image->pixels[i+2];
        image->pixels[i+2] = temp;
        image->pixels[i+3] = 255;
    }
    
    // we're done.
    return 1;
}

// Load Bitmaps And Convert To Textures
unsigned int load_texture(char *filename)
{
    // Load Texture
    Image image_data;
    unsigned int   texture_num;

    // allocate space for texture
    if (!LoadBMP(filename, &image_data)) {
        exit(1);
    }
    
    // Create Texture   
    glGenTextures(1, &texture_num);
    // 2d texture (x and y size)
    glBindTexture(GL_TEXTURE_2D, texture_num);
    
    // scale linearly when image bigger than texture
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
    
    // scale linearly when image smalled than texture
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR); 
    
    // 2d texture, level of detail 0 (normal), 3 components 
    // (red, green, blue), x size from image, y size from image, 
    // border 0 (normal), rgb color data, unsigned byte data, and 
    // finally the data itself.
    
    glTexImage2D(GL_TEXTURE_2D, 0, 3, image_data.sizeX, image_data.sizeY, 0, 
        GL_RGBA, GL_UNSIGNED_BYTE, image_data.pixels);

    free(image_data.pixels);
    return texture_num;
}

Square::Square( int width )
{
	mCenterX=0;
	mCenterY=0;
	mRotate=0.f;
	mWidth=width;
    glBindTexture(GL_TEXTURE_2D, mTexture);
	bTexture=false;
}

void Square::ToggleTexturing()
{
	bTexture=!bTexture;
	if(bTexture)
		glEnable(GL_TEXTURE_2D);
	else
		glDisable(GL_TEXTURE_2D);
}

void Square::Render() 
{
	glLoadIdentity();
	glTranslatef(mCenterX,-mCenterY,0.f);
 	glRotatef(mRotate,0,0,-1.0);
	glBegin(GL_QUADS);
	glTexCoord2f(0.f,1.f);
	glVertex2f(-mWidth/2.f,mWidth/2.f);
	glTexCoord2f(1.f,1.f);
	glVertex2f(mWidth/2.f,mWidth/2.f);
	glTexCoord2f(1.f,0.f);
	glVertex2f(mWidth/2.f,-mWidth/2.f);
	glTexCoord2f(0.f,0.f);
	glVertex2f(-mWidth/2.f,-mWidth/2.f);
	glEnd();
}

void Square::WindowWidth( int w, int h )
{
	mWindWid=w;
	mWindHei=h;
}

void Square::Click( int x, int y )
{
	float posX,posY,B4Rx,B4Ry;
	float Angle = mRotate*MATH_PI/180;
	float SINangle = sin(Angle);
	float COSangle = cos(Angle);
	B4Rx=x-mWindWid/2-mCenterX;
	B4Ry=y-mWindHei/2-mCenterY;

	posX=COSangle*B4Rx+SINangle*B4Ry;
	posY=-SINangle*B4Rx+COSangle*B4Ry;

	bRotate = false;
	bTranslate = false;
	bDrag = false;

	if( ( abs(posX+mWidth/2)<5 && abs(posY-mWidth/2)<5 ) || ( abs(posX-mWidth/2)<5 && abs(posY-mWidth/2)<5 ) || ( abs(posX-mWidth/2)<5 && abs(posY+mWidth/2)<5 ) || ( abs(posX+mWidth/2)<5 && abs(posY+mWidth/2)<5 ))
		bRotate = true;
	else if((posX>-mWidth/2) && (posX<mWidth/2) && (posY>-mWidth/2) && (posY<mWidth/2))
		bTranslate=true;
	else if( (abs(posX+mWidth/2)<5 || abs(posX-mWidth/2)<5) && (posY>-mWidth/2) && (posY<mWidth/2)
		  || (abs(posY+mWidth/2)<5 || abs(posY-mWidth/2)<5) && (posX>-mWidth/2) && (posX<mWidth/2))
		bDrag = true;
	if(bRotate || bTranslate || bDrag)
	{
		mStartPosX=x;
		mStartPosY=y;
	}
}

void Square::Drag( int x, int y )
{
	if( bRotate == true){
		mRotate+=180*(atan2((y-mWindHei/2-mCenterY),(x-mWindWid/2-mCenterX))-atan2((mStartPosY-mWindHei/2-mCenterY),(mStartPosX-mWindWid/2-mCenterX)))/3.1415926;
	}
	if( bTranslate == true){
		mCenterX+=x-mStartPosX;
		mCenterY+=y-mStartPosY;
	}
	if( bDrag == true)
	{
	float posX,posY,B4Rx,B4Ry;
	float Angle = mRotate*MATH_PI/180;
	float SINangle = sin(Angle);
	float COSangle = cos(Angle);
	B4Rx=x-mWindWid/2-mCenterX;
	B4Ry=y-mWindHei/2-mCenterY;

	posX=COSangle*B4Rx+SINangle*B4Ry;
	posY=-SINangle*B4Rx+COSangle*B4Ry;

	if(abs(posX)>=abs(posY))
		mWidth=abs(posX)*2;
	else
		mWidth=abs(posY)*2;
	}
	mStartPosX=x;
	mStartPosY=y;
}