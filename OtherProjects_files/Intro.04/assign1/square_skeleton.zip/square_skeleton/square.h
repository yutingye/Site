#ifndef _SQUARE_H
#define _SQUARE_H

#include <iostream>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

class Square {
private:
	int mWidth;
	int mCenterX;
	int mCenterY;
	int mStartPosX;
	int mStartPosY;
	int mWindWid;
	int mWindHei;
	float mRotate;
	bool bDrag;
	bool bTranslate;
	bool bRotate;
	bool bTexture;
public:
	unsigned int mTexture;
	Square( int width );
	void Render();
	void Click( int x, int y );
	void Drag( int x, int y );
	void WindowWidth( int w, int h );
	void ToggleTexturing();
};

#endif