#include "util.h"
#include <math.h>

enum LightType{AMBIENT,DIRECTIONAL,SPOT,POINT};

struct Hit
{
	double t;
	Point pnt;
	Vec norm;
	Object* shp;
};

struct Light
{
	Color col;
	LightType type;
	virtual Color ambient(Hit& h, Material& mat){return Color(0,0,0);}
	virtual Color diffuse(Hit& h, Material& mat){return Color(0,0,0);}
	virtual Color specular(Ray r, Hit& h, Material& mat){return Color(0,0,0);}
	inline virtual Color intensity(Hit& h){return Color(0,0,0);}
};

struct ambientL: public Light
{
	ambientL(){type=AMBIENT;}
	Color ambient(Hit& h, Material& mat){return mat.ambient.PointMult(intensity(h));}
	inline Color intensity(Hit& h){return col;}
};

struct directionalL: public Light
{
	Vec dir;
	directionalL(){type=DIRECTIONAL;}
	Color diffuse(Hit& h, Material& mat)
	{
		double t = fabs(dir.Dot(h.norm));
		return mat.diffuse.PointMult(intensity(h)*t);
	}
	Color specular(Ray ray, Hit &h, Material& mat)
	{
		Vec r = dir - h.norm*(2*dir.Dot(h.norm));
		r.Normalize();
		return mat.specular.PointMult(intensity(h)*(pow(-ray.dir.Dot(r),mat.phong)));
	}
	inline Color intensity(Hit h)
	{
		return col;
	}
};

struct pointL: public Light
{
	Vec pos;
	pointL(){type=POINT;}
	Color diffuse(Hit& h, Material& mat)
	{
		Vec d = pos - h.pnt;
		d.Normalize();
		double t = fabs(d.Dot(h.norm));
		return mat.diffuse.PointMult(intensity(h)*t);
	}
	Color specular(Ray ray, Hit &h, Material& mat)
	{
		Vec d = h.pnt - pos;
		double dl = d.SMag();
		d.Normalize();
		Vec r = d - h.norm*(2*d.Dot(h.norm));
		r.Normalize();
		return mat.specular.PointMult(intensity(h)*(pow(-ray.dir.Dot(r),mat.phong)));
	}
	inline virtual Color intensity(Hit& h){
		Vec d = pos - h.pnt;
		return col*(1.0/d.SMag());
	}
};

struct spotL: public pointL
{
	Vec dir;
	double angle1;
	double angle2;
	spotL(){type=SPOT;}
	inline Color intensity(Hit& h)
	{
		Vec d = pos - h.pnt;
		double dl = d.SMag();
		d.Normalize();
		double dd = -dir.Dot(d);
		double i;
		double f = cos(angle1) - cos(angle2);
		if(dd>=cos(angle1))
			i = 1/dl;
		else if(dd>=cos(angle2))
			i = dd/(f*dl);
		else
			i=0;
		return col*i;
			
	}
};

