#include "Raytracer.h"
#include <iostream.h>
#include <math.h>

int main(int argc, char **argv)
{
	Scene scene;
	bool bParsable = parseSceneFile(argv[1],scene);
	if(bParsable){
		cout<<"done!"<<endl;
		Pixel* pixels=new Pixel[scene.resolution[0]*scene.resolution[1]];
		int i,j;
		int onePercent = scene.resolution[0]*scene.resolution[1]/100;
		int count=0, finished=1;
		for(i=0;i<scene.resolution[1];i++){
			for(j=0;j<scene.resolution[0];j++){
				if(count++ >= onePercent){
					cout<<finished++<<" percent finished"<<endl; 
					count=0;
				}
				Ray ray = ConstructRays(scene.cam,i,j,scene.resolution);
				Color c = EvaluateRayTree(scene,ray,0);
				pixels[i*scene.resolution[0]+j].SetClamp(c[0]*255,c[1]*255,c[2]*255);
			}
		}	
		FILE* fp = fopen(scene.output,"wb");
		Image img(scene.resolution[0],scene.resolution[1],pixels);
		BMPWriteImage(&img,fp);
		fclose(fp);
		delete pixels;
	}
	else{
		cout<<"failed!"<<endl;
	}
	return 0;
}

Ray ConstructRays(Camera& cam, int i, int j, int resolution[2])
{
	double v[3];
	v[0] = (1.0-2.0*j/(resolution[0]-1.0))*tan(cam.fov)*resolution[0]/(double)resolution[1];//tan(angle[0]);
	v[1] = (1.0-2.0*i/(resolution[1]-1.0))*tan(cam.fov);//tan(angle[1]);
	v[2] = 1;
	Ray r;
	r.dir = cam.right*v[0]+cam.up*v[1]+cam.dir*v[2];
	r.dir.Normalize();
	r.pos = cam.pos;
	return r;
}


Color EvaluateRayTree(Scene& scene, Ray ray, int times)
{
	if(times>scene.maxDepth)
		return scene.bg;
	bool hit_something;
	Hit hit; // structure containing hit point, normal, etc
	hit_something = FindIntersection( scene, ray, hit );
	if (hit_something)
	{
		return scene.ApplyLightModel( ray, hit, times );
	}
	else
	{
		return scene.bg;
	}
}

bool FindIntersection(Scene& scn, Ray r, Hit& hit)
{
	bool flag=false;
	ListNode* n=scn.objs.head;
	hit.t=-1;
	while(n!=NULL){
		Hit h;
		Shape* s=((Object*)n->obj)->shp;
		switch(s->type)
		{
		case SPHERE:
			flag=scn.InterSphere((Sphere*)s,r,h);
			break;
		case NTRIANGLE:
		case TRIANGLE:
			flag=scn.InterTriangle((Triangle*)s,r,h);
			break;
		}
		if(flag && h.t>1e-8 && (h.t<hit.t || hit.t<0)){
			hit.norm=h.norm;
			hit.pnt=h.pnt;
			hit.shp=(Object*)n->obj;
			hit.t=h.t;
		}
		n=n->next;
	}
	return (hit.t>-1);
}
