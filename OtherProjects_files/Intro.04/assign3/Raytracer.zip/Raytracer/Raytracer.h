#include <stdio.h>

#include "util.h"
#include "bmp.h"
#include "image.h"
#include "pixel.h"
#include "Scene.h"
#include "Shapes.h"
//#include "Jpegfile.h"

bool parseSceneFile(char* fn, Scene& scn);
Ray ConstructRays(Camera& cam, int i, int j, int resolution[2]);
bool FindIntersection(Scene& scn, Ray r, Hit& hit);
Color EvaluateRayTree(Scene& scene, Ray ray, int times);
extern void BMPWriteImage(Image *img, FILE *fp);
