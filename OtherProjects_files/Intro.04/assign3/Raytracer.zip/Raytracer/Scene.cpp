#include "Scene.h"
#include <string.h>
#include "util.h"

extern bool FindIntersection(Scene& scn, Ray r, Hit& hit);
extern Color EvaluateRayTree(Scene& scene, Ray ray, int times);

Scene::Scene():bg(0,0,0),maxDepth(5),maxVec(0),numV(0),maxNorm(0),numN(0),vList(NULL),nList(NULL)
{
	resolution[0]=640;
	resolution[1]=480;
	strcpy(output,"out.bmp");
}

Scene::~Scene()
{
	if(vList!=NULL)
		delete []vList;
	if(nList!=NULL)
		delete []nList;
}

void Scene::setCamera(Vec p, Vec f, Vec u, double fov)
{
	cam.pos = p;
	cam.dir = f;
	cam.up = u;
	cam.fov = fov;
	cam.right = cam.dir.cross(cam.up);
}

void Scene::setNormal(Triangle* tri)
{
	Vec p1 = vList[tri->idx[0]]-vList[tri->idx[2]];
	Vec p2 = vList[tri->idx[1]]-vList[tri->idx[2]];
	tri->normal = p1.cross(p2);
	tri->normal.Normalize();
	tri->planeD = -vList[tri->idx[0]].Dot(tri->normal);
}


bool Scene::InterTriangle(Triangle* tri, Ray r, Hit& h)
{
	double sign = r.dir.Dot(tri->normal);
	bool flag = !(sign==0);
	if(flag){
		double t = -((r.pos.Dot(tri->normal))+tri->planeD)/sign;
		Point p = r.pos+r.dir*t;
		if(t>1e-8 && PointInTriangle(p, tri)){
			h.t=t;
			h.norm = tri->normal;
			h.pnt = p;
		}
		else
			flag = false;
	}
	return flag;
}

bool Scene::InterSphere(Sphere* sph, Ray r, Hit& h)
{
	bool flag=false;
	double a=1.0;
	double b=(r.dir+r.dir).Dot((r.pos-sph->center));
	double c=(r.pos-sph->center).SMag()-sph->radius*sph->radius;
	double d=b*b-4*a*c;
	if(d<0)
		flag=false;
	else{
		flag=true;
		double sd = sqrt(d);
		double x1 = (-b+sd)/(2*a);
		double x2 = (-b-sd)/(2*a);
		double t1 = x1<x2?x1:x2;
		double t2 = x1>x2?x1:x2;
		if(t1>1e-8)
			h.t = t1;
		else if(t2>1e-8)
			h.t = t2;
		else
			flag=false;
		if(flag){
			h.pnt=r.pos+r.dir*h.t;
			h.norm = h.pnt - sph->center;
			h.norm.Normalize();
		}	
	}
	return flag;
}

bool Scene::PointInTriangle(Vec p, Triangle* tri)
{
	if(sameside(p, vList[tri->idx[0]], vList[tri->idx[1]], vList[tri->idx[2]])
		&& sameside(p, vList[tri->idx[1]], vList[tri->idx[2]], vList[tri->idx[0]])
		&& sameside(p, vList[tri->idx[2]], vList[tri->idx[0]], vList[tri->idx[1]]))
		return true;
	return false;
}

inline
bool Scene::sameside(Vec p, Vec p1, Vec lp1, Vec lp2)
{
	Vec cp1 = (lp2-lp1).cross(p1-lp1);
	Vec cp2 = (lp2-lp1).cross(p-lp1);
	return (cp1.Dot(cp2)>=0);
}

Color Scene::ApplyLightModel(Ray ray, Hit& hit, int times)
{
	Color contribution(0,0,0);
	ListNode* l=lghts.head;
	Material m = mats.m[hit.shp->mat];
	bool bShadow;
	while(l!=NULL){
		Light* lght = (Light*)l->obj;
		bShadow = true;
		bool blocked;
		Hit shadow_hit;
		Ray* shadow;
		switch(lght->type)
		{
		case POINT:
			shadow = new Ray(hit.pnt, ((pointL*)lght)->pos - hit.pnt);
			blocked = FindIntersection(*this,*shadow,shadow_hit);
			if(!blocked || shadow_hit.t>(((pointL*)lght)->pos - hit.pnt).Magnitude()){
				bShadow = false;
			}
			delete shadow;
			break;
		case SPOT:
			shadow = new Ray(hit.pnt,((spotL*)lght)->pos - hit.pnt);
			blocked = FindIntersection(*this,*shadow,shadow_hit);
			if(!blocked || shadow_hit.t>(((spotL*)lght)->pos - hit.pnt).Magnitude()){
				bShadow = false;
			}
			delete shadow;
			break;
		case DIRECTIONAL:
			shadow = new Ray(hit.pnt, Vec::ZERO-((directionalL*)lght)->dir);
			blocked = FindIntersection(*this,*shadow,shadow_hit);
			if(!blocked )
				bShadow = false;
			delete shadow;
			break;
		}
		contribution = contribution + lght->ambient(hit,m);
		if(!bShadow){
			Color d = lght->diffuse(hit,m);
			Color s = lght->specular(ray, hit, m);
			contribution = contribution + d + s;
		}
		l=l->next;
	}
	if(!(m.specular==Vec::ZERO)){
		Ray mirror = Reflect( ray, hit );
		Color ref = m.specular.PointMult(EvaluateRayTree(*this, mirror, times+1));
		contribution = contribution + ref;
	}
	if(!(m.transmit==Vec::ZERO)){
		Ray glass;
		if(hit.shp->shp->type==SPHERE){
			if(ray.dir.Dot(hit.norm)<0)
				glass = Refract(ray, hit, 1, m.ior);
			else{
				Hit rHit = hit;
				rHit.norm = Vec::ZERO - rHit.norm;
				glass = Refract(ray, rHit, m.ior, 1);
			}
		}
		else
			glass = Ray(hit.pnt, ray.dir);
		Color refract = m.transmit.PointMult(EvaluateRayTree(*this, glass, times+1));
		contribution = contribution  + refract;
	}
	return contribution;
}

inline
Ray Scene::Reflect(Ray ray, Hit h)
{
	Vec r = ray.dir - h.norm*(2*ray.dir.Dot(h.norm));
	r.Normalize();
	return Ray(h.pnt, r);
}

inline 
Ray Scene::Refract(Ray ray, Hit h, double ii, double io)
{
	double cosTheta = -(ray.dir.Dot(h.norm));
	double beta = asin(sin(acos(cosTheta))*ii/io);
	Vec ref = h.norm*(cosTheta*ii/io-cos(beta))+ray.dir*(ii/io);
	ref.Normalize();
	return Ray(h.pnt, ref);
}