#ifndef SCENE_H
#define SCENE_H

#include "util.h"
#include "Shapes.h"
#include "Light.h"
#include <string.h>
#include <math.h>

struct Camera
{
	Vec pos;
	Vec dir;
	Vec up;
	Vec right;
	double fov;
	double wfov;

	Camera():pos(0,0,0),dir(0,0,1),up(0,1,0),fov(DTOR(45)){right=dir.cross(up);}
};

struct ListNode
{
	void* obj;
	ListNode* next;
	ListNode():obj(NULL),next(NULL){}
	~ListNode()
	{
		if(obj!=NULL)
			delete obj;
	}
};

struct List
{
	ListNode* head;
	ListNode* tail;
	int count;

	List():head(NULL),tail(NULL),count(0){}
	~List()
	{
		if(head!=NULL){
			while(head!=tail){
				ListNode* tmp=head;
				head=head->next;
				delete tmp;
			}
			delete head;
		}
	}

	void Insert(void* obj)
	{
		if(head==NULL){
			head=new ListNode();
			head->obj=obj;
			tail=head;
		}
		else{
			tail->next = new ListNode();
			tail=tail->next;
			tail->obj=obj;
		}
		count++;
	}
};

struct matList{
	Material* m;
	int maxNum;
	int count;

	matList(){
		maxNum=10;
		count =1;
		m = new Material[maxNum];
	}

	~matList(){delete []m;}

	void addMat(Color a, Color d, Color s, float phng, Color t, float i)
	{
		if(count==maxNum){
			maxNum +=10;
			Material* tmp = new Material[maxNum];
			memcpy(tmp,m,sizeof(m));
			delete []m;
			m = tmp;
		}
	
		m[count].ambient=a;
		m[count].diffuse=d;
		m[count].specular=s;
		m[count].phong=phng;
		m[count].transmit=t;
		m[count].ior=i;
		count++;
	}
};

class Scene
{
public:
	Color bg;
	int maxDepth;
	int resolution[2];
	char output[32];
	List objs;
	List lghts;
	matList mats;
	Camera cam;
	tVector3* vList;
	tVector3* nList;
	int maxVec;
	int maxNorm;
	int numV;
	int numN;

	Scene();
	~Scene();

	void setCamera(Vec p, Vec f, Vec u, double fov);
	void setNormal(Triangle* tri);
	bool InterSphere(Sphere* sph,Ray r,Hit& h);
	bool InterTriangle(Triangle* tri, Ray r, Hit& h);
	bool PointInTriangle(Vec p, Triangle* tri);
	inline bool sameside(Vec p, Vec p1, Vec lp1, Vec lp2);
	inline Ray Reflect(Ray ray, Hit h);
	inline Ray Refract(Ray ray, Hit h, double ii, double io);
	Color ApplyLightModel(Ray ray, Hit& hit, int times);
};

#endif