#ifndef SHAPES_H
#define SHAPES_H 

#include "util.h"

struct Material
{
	Color ambient;
	Color diffuse;
	Color specular;
	float phong;
	Color transmit;
	float ior;
	Material():ambient(0,0,0),diffuse(1,1,1),specular(0,0,0),phong(5),transmit(0,0,0),ior(1){}
};

enum ShapeType{SPHERE, TRIANGLE, NTRIANGLE};

struct Shape
{
	ShapeType type;
};

struct Object
{
	Shape* shp;
	int mat;
	Object():shp(NULL),mat(0){}
	~Object()
	{
		if(shp!=NULL)
			delete shp;
	}
};

struct Sphere: public Shape
{
	Vec center;
	float radius;
	Sphere(Vec c, float r):center(c),radius(r){type=SPHERE;}
};

struct Triangle: public Shape
{
	int idx[3];
	Vec normal;
	double planeD;
	Triangle(){type=TRIANGLE;}
};

struct nmlTriangle: public Triangle
{
	int nidx[3];
	nmlTriangle(){type=NTRIANGLE;}
};

struct Ray
{
	Vec pos;
	Vec dir;
	Ray(){}
	Ray(Vec p, Vec d):pos(p),dir(d){dir.Normalize();}
};

#endif