#include "image.h"
#include "bmp.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#define MATH_PI 3.1416
/**
 * Image
 **/
Image::Image (int width_, int height_, Pixel* p)
{
    assert(width_ > 0);
    assert(height_ > 0);

    width           = width_;
    height          = height_;
    num_pixels      = width * height;
    pixels          = p;
    sampling_method = IMAGE_SAMPLING_POINT;
    assert(pixels != NULL);
}

Image::~Image ()
{
  //  delete []pixels;
  //  pixels = NULL;
}
