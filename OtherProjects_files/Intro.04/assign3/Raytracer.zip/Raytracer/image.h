/**
 * Image.h
 *
 * Image class.
 *
 * original by Wagner Correa, 1999
 * turned to C++ by Robert Osada, 2000
 **/
#ifndef IMAGE_INCLUDED
#define IMAGE_INCLUDED

#include <assert.h>
#include <stdio.h>
#include "pixel.h"


/**
 * constants
 **/
enum {
    IMAGE_SAMPLING_POINT,
    IMAGE_SAMPLING_BILINEAR,
    IMAGE_SAMPLING_GAUSSIAN,
    IMAGE_N_SAMPLING_METHODS
};

/**
 * Image
 **/
class Image
{
public:
    Pixel *pixels;
    int width, height, num_pixels;
    int sampling_method;

public:
    // Creates a blank image with the given dimensions
    Image (int width, int height, Pixel* p);


    // Destructor
    ~Image ();

    // Pixel access
    int ValidCoord (int x, int y)  { return x>=0 && x<width && y>=0 && y<height; }
    Pixel& GetPixel (int x, int y) { assert(ValidCoord(x,y)); return pixels[y*width + x]; }

    // Dimension access
    int Width     () { return width; }
    int Height    () { return height; }
    int NumPixels () { return num_pixels; }
};

#endif
