#include "Raytracer.h"
#include <fstream.h>
#include <iostream.h>

bool parseSceneFile(char* fileName, Scene& scn)
{
	cout<<"Loading "<<fileName<<"...";

	ifstream fp(fileName);

	char buff[1024];
	char keyword[20];

	int isEnd;
	while(1)
	{
		fp.getline(buff,1024);
		strcpy(keyword,"");
		isEnd=sscanf(buff,"%s",keyword);
		if(keyword[0]=='#')
			continue;
		if(strcmp(keyword,"camera")==0){
			Vec v[3];
			double ang;
			sscanf(buff,"%s %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",keyword,
						&v[0][0],&v[0][1],&v[0][2],
						&v[1][0],&v[1][1],&v[1][2],
						&v[2][0],&v[2][1],&v[2][2],&ang);
			scn.setCamera(v[0],v[1],v[2],DTOR(ang));
		}
		else if(strcmp(keyword,"film_resolution")==0){
			sscanf(buff,"%s %d %d",keyword,&scn.resolution[0],&scn.resolution[1]);
		}
		else if(strcmp(keyword,"max_depth")==0){
			sscanf(buff,"%s %d",keyword,&scn.maxDepth);
		}
		else if(strcmp(keyword,"output_image")==0){
			sscanf(buff,"%s %s",keyword,&scn.output);
		}
		else if(strcmp(keyword,"background")==0){
			sscanf(buff,"%s %lf %lf %lf",keyword,&scn.bg[0],&scn.bg[1],&scn.bg[2]);
		}
		else if(strcmp(keyword,"max_normals")==0){
			sscanf(buff,"%s %d",keyword,&scn.maxNorm);
			scn.nList = new tVector3[scn.maxNorm];
		}
		else if(strcmp(keyword,"max_vertices")==0){
			sscanf(buff,"%s %d",keyword,&scn.maxVec);
			scn.vList = new tVector3[scn.maxVec];
		}
		else if(strcmp(keyword,"vertex")==0){
			double tmp[3];
			sscanf(buff,"%s %lf %lf %lf",keyword,&tmp[0],&tmp[1],&tmp[2]);
			scn.vList[scn.numV++]=tVector3(tmp[0],tmp[1],tmp[2]);
		}
		else if(strcmp(keyword,"material")==0){
			Material m;
			sscanf(buff, "%s %lf %lf %lf %lf %lf %lf %lf %lf %lf %f %lf %lf %lf %f",keyword,
				&m.ambient[0],&m.ambient[1],&m.ambient[2],
				&m.diffuse[0],&m.diffuse[1],&m.diffuse[2],
				&m.specular[0],&m.specular[1],&m.specular[2],&m.phong,
				&m.transmit[0],&m.transmit[1],&m.transmit[2],&m.ior);
			scn.mats.addMat(m.ambient,m.diffuse,m.specular,m.phong,m.transmit,m.ior);
		}
		else if(strcmp(keyword,"triangle")==0){
			Triangle* tri = new Triangle();
			sscanf(buff,"%s %d %d %d",keyword, &tri->idx[0],&tri->idx[1],&tri->idx[2]);
			scn.setNormal(tri);
			Object* obj = new Object();
			obj->shp = tri;
			obj->mat = scn.mats.count-1;
			scn.objs.Insert(obj);
		}
		else if(strcmp(keyword,"normal_triangle")==0){
			nmlTriangle* ntri = new nmlTriangle();
			sscanf(buff,"%s %d %d %d %d %d %d",keyword,
				&ntri->idx[0],&ntri->idx[1],&ntri->idx[2],
				&ntri->nidx[0],&ntri->nidx[1],&ntri->nidx[2]);
			Object* obj = new Object();
			obj->shp = ntri;
			obj->mat = scn.mats.count-1;
			scn.objs.Insert(obj);
		}
		else if(strcmp(keyword,"sphere")==0){
			Vec c;
			float r;
			sscanf(buff,"%s %lf %lf %lf %f",keyword,&c[0],&c[1],&c[2],&r);
			Object* obj = new Object();
			obj->shp = new Sphere(c,r);
			obj->mat = scn.mats.count-1;
			scn.objs.Insert(obj);
		}
		else if(strcmp(keyword,"point_light")==0){
			pointL* pl = new pointL();
			sscanf(buff,"%s %lf %lf %lf %lf %lf %lf",keyword,
				&pl->col[0],&pl->col[1],&pl->col[2],
				&pl->pos[0],&pl->pos[1],&pl->pos[2]);
			scn.lghts.Insert(pl);
		}
		else if(strcmp(keyword,"spot_light")==0){
			spotL* sl = new spotL();
			sscanf(buff,"%s %lf %lf %lf %lf %lf %lf %lf %lf %lf %f %f",keyword,
				&sl->col[0],&sl->col[1],&sl->col[2],
				&sl->pos[0],&sl->pos[1],&sl->pos[2],
				&sl->dir[0],&sl->dir[1],&sl->dir[2],
				&sl->angle1,&sl->angle2);
			sl->angle1 = DTOR(sl->angle1);
			sl->angle2 = DTOR(sl->angle2);
			sl->dir.Normalize();
			scn.lghts.Insert(sl);
		}
		else if(strcmp(keyword,"ambient_light")==0){
			ambientL* am = new ambientL();
			sscanf(buff,"%s %lf %lf %lf",keyword,&am->col[0],&am->col[1],&am->col[2]);
			scn.lghts.Insert(am);
		}
		else if(strcmp(keyword,"directional_light")==0){
			directionalL* dl = new directionalL();
			sscanf(buff,"%s %lf %lf %lf %lf %lf %lf", keyword,
				&dl->col[0],&dl->col[1],&dl->col[2],
				&dl->dir[0],&dl->dir[1],&dl->dir[2]);
			dl->dir.Normalize();
			scn.lghts.Insert(dl);
		}
		else if(strcmp(keyword,"")){
			cout<<"Undefined keyword: "<<keyword<<endl;
			fp.close();
			return false;
		}
		if(fp.eof()==1)
			break;
	}
	fp.close();
	return true;
}