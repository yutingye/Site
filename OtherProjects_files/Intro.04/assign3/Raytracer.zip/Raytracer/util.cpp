#include <math.h>
#include "util.h"

#define _X 0
#define _Y 1
#define _Z 2

#define SIGN(a, b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))

//extern int dsvd (tMatrix& a, int m, int n, double *w, tMatrix& v);

static double pythag (double a, double b)
{
	double at = fabs(a), bt = fabs(b), ct, result;
 
	if (at > bt)     { ct = bt / at; result = at * sqrt(1.0 + ct * ct); }
	else if (bt > 0.0) { ct = at / bt; result = bt * sqrt(1.0 + ct * ct); }
	else result = 0.0;
	return(result);
}

tVector3 tVector3::ZERO(0,0,0);

tVector3::tVector3()
{
	vec[0]=vec[1]=vec[2]=0;
}
	
tVector3::tVector3 (double new_x, double new_y, double new_z)
{
	vec[_X]=new_x;
	vec[_Y]=new_y;
	vec[_Z]=new_z;
}
	
tVector3::tVector3 (const tVector3& v)
{
	for(int i=0;i<3;i++)
		vec[i]=v[i];
}

tVector3 tVector3::cross(const tVector3 &v)
{
	tVector3 temp;
	temp[_X] = ((vec[_Y] * v[_Z]) - (vec[_Z] * v[_Y]));
	temp[_Y] = ((vec[_Z] * v[_X]) - (vec[_X] * v[_Z]));
	temp[_Z] = ((vec[_X] * v[_Y]) - (vec[_Y] * v[_X]));
	return temp;
}

double tVector3::Dot(const tVector3 &v)
{
	double sum=0;
	for(int i=0;i<3;i++)
		sum += vec[i]*v[i];
	return sum;
}

double tVector3::Magnitude()
{
	double sum=0;
	for(int i=0;i<3;i++)
		sum+=vec[i]*vec[i];
	return sqrt(sum);
}

double tVector3::SMag()
{
	double sum=0;
	for(int i=0;i<3;i++)
		sum+=vec[i]*vec[i];
	return sum;
}

void tVector3::Normalize()
{
	double m=Magnitude();
	if(m>1e-20){
		for(int i=0;i<3;i++)
			vec[i]/=m;
	}
	else{
		vec[0]=vec[1]=vec[2]=0;
	}
}

void tVector3::scale(double scaler)
{
	for(int i=0;i<3;i++)
		vec[i] *= scaler;
}

tVector3 tVector3::operator + (const tVector3 &v)
{
	tVector3 temp;
	for(int i=0;i<3;i++)
		temp[i] = vec[i] + v[i];
	return temp;
}

tVector3 tVector3::operator - (const tVector3 &v)
{
	tVector3 temp;
	for(int i=0;i<3;i++)
		temp[i] = vec[i] - v[i];
	return temp;
}

tVector3 tVector3::operator * (const double s)
{
	tVector3 temp;
	for(int i=0;i<3;i++)
		temp[i] = s*vec[i];
	return temp;
}

tVector3& tVector3::operator = (const tVector3 &v)
{
	for(int i=0;i<3;i++)
		vec[i] = v[i];
	return (*this);
}

bool tVector3::operator == (const tVector3 &v)
{
	return (vec[0]==v[0] && vec[1]==v[1] && vec[2]==v[2]);
}

tVector3 tVector3::PointMult(const tVector3 &v)
{
	return tVector3(vec[0]*v[0],vec[1]*v[1],vec[2]*v[2]);
}

tMatrix::tMatrix(int rs,int cs)
{
    int i,j;
    rows = rs;
    columns = cs;
    data = new double*[rows];
    for(i = 0; i < rows; i++){
        data[i] = new double[columns];
    }
    for(i = 0; i < rows; i++){
        for(j = 0; j < columns; j++)
            data[i][j] = 0.0;
    }
}

tMatrix::tMatrix(const tMatrix& m)
{
	int i,j;
	rows = m.rows;
	columns = m.columns;
	data = new double*[rows];
	for(i=0;i<rows;i++)
		data[i] = new double[columns];
    for(i = 0; i < rows; i++){
        for(j = 0; j < columns; j++)
            data[i][j] = m[i][j];
    }
}

tMatrix::tMatrix(int rs, int cs, double d[])
{
    int i,j;
    rows = rs;
    columns = cs;
    data = new double*[rows];
    for(i = 0; i < rows; i++){
        data[i] = new double[columns];
    }
    for(i = 0; i < rows; i++){
        for(j = 0; j < columns; j++)
            data[i][j] = d[i*columns+j];
    }
}

tMatrix& tMatrix::operator = (const tMatrix& m)
{
	int i,j;
    for(i = 0; i < rows; i++){
        for(j = 0; j < columns; j++)
            data[i][j] = m[i][j];
    }
	return (*this);
}

tMatrix::~tMatrix()
{
    for(int i = 0; i < rows; i++){
        delete[] data[i];
    }	
    delete[] data;
}

tMatrix tMatrix::Multiply(const tMatrix& m)
{
	tMatrix temp(this->rows, m.columns);
	for(int i=0;i<temp.rows;i++){
		for(int j=0;j<temp.columns;j++){
			temp[i][j]=0;
			for(int p=0;p<this->columns;p++){
					temp[i][j]+=data[i][p]*m[p][j];
			}
		}
	}
	return temp;
}

double* tMatrix::Multiply(tVector3& v)
{
	double* temp = new double[this->rows];
	for(int i=0;i<this->rows; i++){
		temp[i] = 0;
		for(int j=0;j<3; j++){
			temp[i] += (*this)[i][j] * v[j];
		}
	}
	return temp;
}

double* tMatrix::Multiply(double* a)
{
	double* temp = new double[this->rows];
	for(int i=0;i<this->rows;i++){
		temp[i] = 0;
		for(int j=0;j<this->columns;j++){
			temp[i] += (*this)[i][j]*a[j];
		}
	}
	return temp;
}

tMatrix tMatrix::transpose()
{
	tMatrix temp(this->columns, this->rows);
	for(int i=0;i<temp.rows;i++){
		for(int j=0;j<temp.columns;j++){
			temp[i][j]=data[j][i];
		}
	}
	return temp;
}

tMatrix tMatrix::Inverse()
{
	tMatrix copy=(*this);
	int* inx=new int[rows];
	double* b=new double[rows];
	for(int i=0; i<rows; i++)
		b[i]=0;
	int d;
	tMatrix m = this->inv(inx, b, d);
	(*this) = copy;
	delete []inx;
	delete []b;
	return m;
}


// Determines the LU Decomposition of a Matrix
//	matA is the n�n matrix and get destroyed
//		by the function, vecI is a vector to 
//			store the row changes that occur,
//				d is just to say if the num of
//					changes was even of odd
bool tMatrix::LU(int* vecI, int &d)
{
	const double TINY = 1.0e-20;
	int i, imax, j, k, n;
	double big, dum, sum, temp;

	n = this->rows;
	double* vv=new double[n];
	d = 1;
	for (i = 0; i < n; i++)
	{
		big = 0.0;
		for(j = 0; j < n; j++)
		{
			if ( ( temp = fabs(data[i][j]) ) > big )
				big = temp;
		}
		if (big == 0.0)
			return false;
		vv[i] = 1.0/big;
	}
	for (j = 0; j < n; j++)
	{
		for (i = 0; i < j; i++)
		{
			sum = data[i][j];
			for (k = 0; k < i; k++)
				sum -= data[i][k] * data[k][j];
			data[i][j] = sum;
		}
		big = 0.0;
		for (i = j; i < n; i++)
		{
			sum = data[i][j];
			for (k = 0; k < j; k++)
				sum -= data[i][k] * data[k][j];
			data[i][j] = sum;
			if ( (dum = vv[i] * fabs(sum)) >= big)
			{
				big = dum;
				imax = i;
			}
		}
		if (j != imax)
		{
			for (k = 0; k < n; k++)
			{
				dum = data[imax][k];
				data[imax][k] = data[j][k];
				data[j][k] = dum;
			}
			d = -d;
			vv[imax] = vv[j];
		}
		vecI[j] = imax;
		if (data[j][j] == 0.0)
			data[j][j] = TINY;
		if (j != n-1)
		{
			dum = 1.0/(data[j][j]);
			for (i = j + 1; i < n; i++)
				data[i][j] *= dum;
		}
	}
	return true;
}

// Simple backsubstitution for a LU decomposed matrix
//	matA is the LU decomposed matrix, vecI is the vector
//	that has the row changes from LU, and vecB is the vector 
//	of the numbers on the rhs of the '='
void tMatrix::LUbcksub(int* vecI, double* vecB)
{
	int i, ii = 0, ip, j, n;
	double sum;
	n = this->rows;

	for (i = 0; i < n; i++)
	{
		ip = vecI[i];
		sum = vecB[ip];
		vecB[ip] = vecB[i];
		if (ii != 0)
		{
			for (j = ii - 1; j < i; j++)
				sum -= data[i][j] * vecB[j];
		}
		else if (sum != 0.0)
			ii = i + 1;
		vecB[i] = sum;
	}
	for(i = n - 1; i >= 0; i--)
	{
		sum = vecB[i];
		for (j = i + 1; j < n; j++)
			sum -= data[i][j] * vecB[j];
		vecB[i] = data[i][i]==0?0:sum/(data[i][i]);
	}
}

// Same as above but calls LU for you
tMatrix tMatrix::inv(int* indx, double* b, int &d)
{
	if(!LU(indx, d))
		return (*this).transpose();

	const int N = this->rows;
	tMatrix y(N, N);
	int i, j;
	for (j = 0; j < N; j++)
	{
		for (i = 0; i < N; i++)
			b[i] = 0.0;
		b[j] = 1.0;
		LUbcksub(indx, b);
		for(i = 0; i < N; i++)
			y[i][j] = b[i];
	}
	return y;
}

tMatrix tMatrix::operator + (const tMatrix& m)
{
	int i,j,r,c;
	r = this->rows;
	c = this->columns;
	tMatrix mat(r,c);
	for(i=0;i<r;i++){
		for(j=0; j<c; j++)
			mat[i][j] = data[i][j] + m[i][j];
	}
	return mat;
}

tMatrix tMatrix::operator - (const tMatrix& m)
{
	int i,j,r,c;
	r = this->rows;
	c = this->columns;
	tMatrix mat(r,c);
	for(i=0;i<r;i++){
		for(j=0; j<c; j++)
			mat[i][j] = data[i][j] - m[i][j];
	}
	return mat;
}

tMatrix tMatrix::operator * (const double s)
{
	int i,j,r,c;
	r = this->rows;
	c = this->columns;
	tMatrix mat(r,c);
	for(i=0;i<r;i++){
		for(j=0;j<c;j++)
			mat[i][j] = (double)(data[i][j]*s);
	}
	return mat;
}

tMatrix tMatrix::Identity(int d)
{
	tMatrix temp(d,d);
	for(int i=0;i<d;i++){
		for(int j=0;j<d;j++){
			if(i==j)
				temp[i][j]=1;
			else
				temp[i][j]=0;
		}
	}
	return temp;
}

/****************************************************/
// SVD algorithm
///////////////////////////////////////////////////////
// GO through and find error!!!!					 //
///////////////////////////////////////////////////////
bool svd(tMatrix &a, double w[], tMatrix &v)
{
	bool flag;
	int i, its, j, jj, k, l, nm, M = a.rows, N = a.columns;
	double anorm = 0.0, c, f, g = 0.0, h, s, scale = 0.0, x, y, z;
	double* rv1=new double[N];

	for(i = 0; i < N; i++)
	{
		l = i + 2;
		rv1[i] = scale * g;
		g = scale = s = 0.0;
		if (i < M)
		{
			for(k = i; k < M; k++)
				scale += fabs(a[k][i]);
			if (scale != 0.0)
			{
				for(k = i; k < M; k++)
				{
					a[k][i] /= scale;
					s += a[k][i] * a[k][i];
				}
				f = a[i][i];
				g = -SIGN(sqrt(s), f);
				h = f * g - s;
				a[i][i] = f - g;
				for(j = l - 1; j < N; j++)
				{
					for(s = 0.0, k = i; k < M; k++)
						s += a[k][i] * a[k][i];
					f = s / h;
					for(k = i; k < M; k++)
						a[k][j] += f * a[k][i];
				}
				for(k = i; k < M; k++)
					a[k][i] *= scale;
			}
		}
		w[i] = scale * g;
		g = scale = s = 0.0;
		if (i + 1 <= M && i != N)
		{
			for(k = l - 1; k < N; k++)
				scale += fabs(a[i][k]);
			if (scale != 0.0)
			{
				for(k = l - 1; k < N; k++)
				{
					a[i][k] /= scale;
					s += a[i][k] * a[i][k];
				}
				f = a[i][l-1];
				g = -SIGN(sqrt(s), f);
				h = f * g - s;
				a[i][l-1] = f - g;
				for (k = l - 1; k < N; k++)
					rv1[k] = a[i][k] / h;
				for (j = l - 1; j < M; j++)
				{
					for (s = 0.0, k = l - 1; k < N; k++)
						s += a[j][k] * a[i][k];
					for (k = l - 1; k < N; k++)
						a[j][k] += s * rv1[k];
				}
				for (k = l - 1; k < N; k++)
					a[i][k] *= scale;
			}
		}
		anorm = MAX( anorm, ( fabs(w[i]) + fabs(rv1[i]) ) );
	}
	for(i = N - 1; i >= 0; i--)
	{
		if (i < N-1)
		{
			if ( g != 0.0 )
			{
				for(j = l; j < N; j++)
					v[j][i] = (a[i][j]/a[i][l])/g;
				for(j = l; j < N; j++)
				{
					for(s = 0.0, k = l; k < N; k++)
						s += a[i][k] * v[k][j];
					for (k = l; k < N; k++)
						v[k][j] += s * v[k][i];
				}
			}
			for (j = l; j < N; j++)
				v[i][j] = v[j][i] = 0.0;
		}
		v[i][i] = 1.0;
		g = rv1[i];
		l = i;
	}
	for(i = MIN(M, N) - 1; i >= 0; i--)
	{
		l = i + 1;
		g = w[i];
		for(j = l; j < N; j++)
			a[i][j] = 0.0;
		if (g != 0.0)
		{
			g = 1.0/g;
			for(j = l; j < N; j++)
			{
				for(s = 0.0, k = l; k < M; k++)
					s += a[k][i] * a[k][j];
				f = (s/a[i][i])*g;
				for(k = i; k < M; k++)
					a[k][j] += f * a[k][i];
			}
			for(j = i; j < M; j++)
				a[j][i] *= g;
		}
		else
		{
			for(j = i; j < M; j++)
				a[j][i] = 0.0;
		}
		++a[i][i];
	}
	for(k = N - 1; k >= 0; k--)
	{
		for(its = 0; its < 30; its++)
		{
			flag = true;
			for (l = k; l >= 0; l--)
			{
				nm = l - 1;
				if( (fabs(rv1[l]) + anorm) == anorm )
				{
					flag = false;
					break;
				}
				if( (fabs(w[nm]) + anorm) == anorm )
					break;
			}
			if (flag)
			{
				c = 0.0;
				s = 1.0;
				for(i = l-1; i < k+1; i++)
				{
					f = s * rv1[i];
					rv1[i] = c * rv1[i];
					if ( (fabs(f) + anorm) == anorm)
						break;
					g = w[i];
					h = pythag(f, g);
					w[i] = h;
					h = 1.0 / h;
					c = g * h;
					s = -f * h;
					for(j = 0; j < M; j++)
					{
						y = a[j][nm];
						z = a[j][i];
						a[j][nm] = y * c + z * s;
						a[j][i] = z * c - y * s;
					}
				}
			}
			z = w[k];
			if ( l == k )
			{
				if (z < 0.0)
				{
					w[k] = -z;
					for(j = 0; j < N; j++)
						v[j][k] = -v[j][k];
				}
				break;
			}
			if (its == 29)
				return false;	// no convergence
			x = w[l];
			nm = k - 1;
			y = w[nm];
			g = rv1[nm];
			h = rv1[k];
			f = ( (y - z) * (y + z) + (g - h) * (g + h) ) / (2.0 * h * y);
			g = pythag(f, 1.0);
			f = ( (x - z) * (x + z) + h * ( (y / (f + SIGN(g, f)) ) - h ) ) / x;
			c = s = 1.0;
			for (j = l; j < nm; j++)
			{
				i = j + 1;
				g = rv1[i];
				y = w[i];
				h = s * g;
				g = c * g;
				z = pythag(f, h);
				rv1[j] = z;
				c = f/z;
				s = h/z;
				f = x * c + g * s;
				g = g * c - x * s;
				h = y * s;
				y *= c;
				for (jj = 0; jj < N; jj++)
				{
					x = v[jj][j];
					z = v[jj][i];
					v[jj][j] = x * c + z * s;
					v[jj][i] = z * c - x * s;
				}
				z = pythag(f, h);
				w[j] = z;
				if (z)
				{
					z = 1.0/z;
					c = f * z;
					s = h * z;
				}
				f = c * g + s * y;
				x = c * y - s * g;
				for(jj = 0; jj < M; jj++)
				{
					y = a[jj][j];
					z = a[jj][i];
					a[jj][j] = y * c + z * s;
					a[jj][i] = z * c - y * s;
				}
			}
			rv1[l] = 0.0;
			rv1[k] = f;
			w[k] = x;
		}
	}
	return true;
}

/*    
tMatrix svdInverse(tMatrix& a)
{
	int m = a.rows, n =a.columns;
	bool flag=false;
	if(m<n){
		flag=true;
		m=a.columns;
		n=a.rows;
	}
	double *w=new double[n];
	double lumda=1e-8;
	tMatrix v(n,n);
	tMatrix W(n,n);
	tMatrix b(m,n);
	if(flag){
		b=a.transpose();	
		dsvd(b,m,n,w,v);
	}
	else
		dsvd(a,m,n,w,v);
	int i;
	for(i=0;i<n;i++){
		W[i][i] =w[i]/(w[i]*w[i]+lumda);// fabs(w[i])>1e-4?1.0/w[i]:0;
	}
	delete []w;
	tMatrix temp(n,m);
	if(flag){
		temp = v.Multiply(W).Multiply(b.transpose());
		return temp.transpose();
	}
	else{
		temp = v.Multiply(W).Multiply(a.transpose());
		return temp;
	}
}
*/

// Simple Backsubstitution for SVD
//	Solves U�x=b for x
//	maxS is the maximum singular value
void svdBcksub(tMatrix &u, double w[], tMatrix &v, double b[], double x[], double maxS = 0.0)
{
	const int N = u.columns;
	const int M = u.rows;
	int i, j, jj;
	double s, min;
	double* tmp = new double[N];

	for(j = 0; j < N; j++)
	{
		if (w[j] > maxS)
			maxS = w[j];
	}
	min = maxS * 1.0e-12;
	for (j = 0; j < N; j++)
	{
		if (w[j] < min)
			w[j] = 0.0;
	}

	for(j = 0; j < N; j++)
	{
		s = 0.0;
		if(w[j] != 0.0)
		{
			for(i = 0; i < M; i++)
				s += u[i][j] * b[i];
			s /= w[j];
		}
		tmp[j] = s;
	}
	for(j = 0; j < N; j++)
	{
		s = 0.0;
		for(jj = 0; jj < N; jj++)
			s += v[j][jj] * tmp[jj];
		x[j] = s;
	}
}
/****************************************************/

tQuat tQuat::Multiply(const tQuat& q)
{
	tQuat temp;
	temp.s = this->s*q.s - this->v.Dot(q.v);
	for(int i=0; i<3; i++)
		temp.v[i] = s*q.v[i] + q.s*v[i];
	temp.v = temp.v + v.cross(q.v);
	return temp;
}

tQuat tQuat::operator + (tQuat& q)
{
	tQuat temp;
	temp.s = this->s + q.s;
	temp.v = this->v + q.v;
	return temp;
}

tQuat tQuat::operator * (const double s)
{
	tQuat temp;
	temp.s = this->s*s;
	temp.v = this->v *s;
	return temp;
}

tQuat& tQuat::operator = (const tQuat& q)
{
	this->v = q.v;
	this->s = q.s;
	return (*this);
}

tQuat tQuat::Conjugate()
{
	tQuat temp;
	temp.s = this->s;
	temp.v = this->v * (-1);
	return temp;
}

void tQuat::normalize()
{
	double l = sqrt(s*s + v[_X]*v[_X] + v[_Y]*v[_Y] + v[_Z]*v[_Z]);
	s /= l;
	v.scale(1.f/l);
}

void tQuat::toMatrix(tMatrix& m)
{
	m[0][0] = 1 - 2*v[_Y]*v[_Y] - 2*v[_Z]*v[_Z];
	m[0][1] = 2*v[_X]*v[_Y] - 2*s*v[_Z];
	m[0][2] = 2*v[_X]*v[_Z] + 2*s*v[_Y];

	m[1][0] = 2*v[_X]*v[_Y] + 2*s*v[_Z]; 
	m[1][1] = 1 - 2*v[_X]*v[_X] - 2*v[_Z]*v[_Z];
	m[1][2] = 2*v[_Y]*v[_Z] - 2*s*v[_X];

	m[2][0] = 2*v[_X]*v[_Z] - 2*s*v[_Y];
	m[2][1] = 2*v[_Y]*v[_Z] + 2*s*v[_X];
	m[2][2] = 1 - 2*v[_X]*v[_X] - 2*v[_Y]*v[_Y];
}

void tQuat::toAxisAngle(tVector3& vec, double& a)
{
	double l = v[_X]*v[_X] + v[_Y]*v[_Y] + v[_Z]*v[_Z];
	if( fabs(l)>0.00001){
		vec[_X] = v[_X] / l;
		vec[_Y] = v[_Y] / l;
		vec[_Z] = v[_Z] / l;
	}
	else
		vec = tVector3::ZERO;
	a = 180 * (double)(2*acos(s)/M_PI);
}

