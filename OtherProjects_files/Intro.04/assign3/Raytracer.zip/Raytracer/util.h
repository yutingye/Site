#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>

#ifndef M_PI
#define M_PI 3.1415926535897932
#endif

#define RTOD(r) (r*180/M_PI)
#define DTOR(d) (d*M_PI/180)

struct tVector3					// expanded 3D vector struct
{			
private:
	double vec[3];

public:
	tVector3();
	tVector3 (double new_x, double new_y, double new_z);	 
	tVector3 (const tVector3& v);

	static tVector3 ZERO;

	tVector3 operator + ( const tVector3& v);
	tVector3 operator - ( const tVector3& v);
    tVector3& operator = ( const tVector3 &v);
	tVector3 operator * (const double s);
	bool operator == (const tVector3& v);
    tVector3 cross(const tVector3& v);
    double Dot(const tVector3& v);
	tVector3 PointMult(const tVector3& v);
	
	void scale(double scaler);
   
	void Normalize();
	double Magnitude();
	double SMag();
	
	double& operator [](int i){ return (vec[i]); }
    const double& operator [](int i) const { return (vec[i]); }

};


typedef tVector3 Vec;
typedef tVector3 Color;
typedef tVector3 Point;


struct tMatrix
{
private:
    double** data;
public:
    int rows;
    int columns;

	tMatrix(){}
    tMatrix(int rs,int cs);
	tMatrix(const tMatrix& m);
	tMatrix(int rs, int cs, double d[]);
    ~tMatrix();
    
	double *operator [](int i) { return data[i]; }
    const double *operator [](int i) const { return data[i]; }
	tMatrix operator + (const tMatrix& m);
	tMatrix operator - (const tMatrix& m);
	tMatrix operator * (const double s);
	tMatrix& operator = (const tMatrix& m);

	tMatrix Multiply(const tMatrix& m);
	double* Multiply(tVector3& v);
	double* Multiply(double* a);
	tMatrix transpose();
	tMatrix Inverse();
	bool LU(int* vecI, int &d);
	void LUbcksub(int* vecI, double* vecB);
	tMatrix inv(int* indx, double* b, int &d);
	static tMatrix Identity(int d);
};

struct tQuat
{
	tVector3 v;
	double s;

	tQuat(double w=1, double v1=0, double v2=0, double v3=0): s(w), v(v1,v2,v3) {}
	tQuat(const tVector3& vec,double w=1): s(w), v(vec) {}
	tQuat(const tQuat& q){v=q.v;s=q.s;}

	tQuat Multiply(const tQuat& q);
	tQuat Conjugate();
	void normalize();
	void toMatrix(tMatrix& m);
	void toAxisAngle(tVector3& vec, double& a);
	tQuat operator + (tQuat& q);
	tQuat operator * (const double s);
	tQuat& operator = (const tQuat& q);
};

#define DOT(v1,v2) \
	(v1[0]*v2[0]+v1[1]*v2[1]+v1[2]*v2[2])

#define Cross(r, v1, v2) \
{ \
	r[0] = v1[1]*v2[2]-v1[2]*v2[1]; \
	r[1] = v1[2]*v2[0]-v1[0]*v2[2]; \
	r[2] = v1[0]*v2[1]-v1[1]*v2[0]; \
}

#define dis(r, v1, v2) \
{ \
	r[0] = v1[0] - v2[0]; \
	r[1] = v1[1] - v2[1]; \
	r[2] = v1[2] - v2[2]; \
}

#define Scale(r, v, s) \
{ \
	r[0] = v[0]*s; \
	r[1] = v[1]*s; \
	r[2] = v[2]*s; \
}

#define Add(r, v1, v2) \
{ \
	r[0] = v1[0] + v2[0]; \
	r[1] = v1[1] + v2[1]; \
	r[2] = v1[2] + v2[2]; \
}

#define Inertiate(M,v) \
{ \
	M[0][0]=v[1]*v[1]+v[2]*v[2]; \
	M[0][1]=-v[0]*v[1]; \
	M[0][2]=-v[0]*v[2]; \
	M[1][0]=-v[1]*v[0]; \
	M[1][1]=v[0]*v[0]+v[2]*v[2]; \
	M[1][2]=-v[1]*v[2]; \
	M[2][0]=-v[2]*v[0]; \
	M[2][1]=-v[2]*v[1]; \
	M[2][2]=v[0]*v[0]+v[1]*v[1]; \
}

#define M12toM9(Md,Ms) \
{ \
	Md[0][0] = Ms[0]; \
	Md[0][1] = Ms[1]; \
	Md[0][2] = Ms[2]; \
	Md[1][0] = Ms[4]; \
	Md[1][1] = Ms[5]; \
	Md[1][2] = Ms[6]; \
	Md[2][0] = Ms[8]; \
	Md[2][1] = Ms[9]; \
	Md[2][2] = Ms[10]; \
}

#define Transpose(r, m) \
{ \
	r[0][0]=m[0][0]; \
	r[0][1]=m[1][0]; \
	r[0][2]=m[2][0]; \
	r[0][3]=m[3][0]; \
	r[1][0]=m[0][1]; \
	r[1][1]=m[1][1]; \
	r[1][2]=m[2][1]; \
	r[1][3]=m[3][1]; \
	r[2][0]=m[0][2]; \
	r[2][1]=m[1][2]; \
	r[2][2]=m[2][2]; \
	r[2][3]=m[3][2]; \
	r[3][0]=m[0][3]; \
	r[3][1]=m[1][3]; \
	r[3][2]=m[2][3]; \
	r[3][3]=m[3][3]; \
}
#endif

