#include <fstream>
#include <string>
#include <math.h>
#include "timer.h"
#include "Cube.h"

using namespace std;

Cube::Cube(float t, unsigned int d, unsigned int s)
{
	this->dimension = d;
	this->scramble_moves = s;
	this->turn_time = t;

	this->moves = NULL;
	this->numScramble = 0;

	elevation = azimuth = 0;

	Vx=Vy=Tx=Ty=0;

	x=y=z=Angle=0;
	animatedAngle=0;
	bTextured = false;
	bAnimated = false;
	bPaused = false;
	buildList();

	string prefix = ".\\images\\";
	string fileName[] = {"orange", "red", "green", "yellow", "white", "blue"}; 
	string fileNum [] = {"1","2","3","4","5","6","7","8","9"};
	string file;
	FILE* F;
		
	glGenTextures(54, texture);
	for(int i=0; i<54; i++)
	{
		file = prefix + fileName[i/9] + fileNum[i%9]+".raw";
		F = fopen(file.data(),"r");
		if(F!=NULL){
			fread(texBuff, sizeof(char), 256*256*3, F);
			fclose(F);
			glBindTexture(GL_TEXTURE_2D, texture[i]); 
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, texBuff);
		}
	}

	Color c[] = {{1.f,0.5f,0}, {1.f,0,0},{0,1.f,0} , {1.f,1.f,0}, {1.f,1.f,1.f}, {0,0,1.f}}; 
	for(int i=0; i<6; i++)
	{
		Faces[i].Creat(dimension);
		for(unsigned int p=0; p<dimension; p++)
			for(unsigned int q=0; q<dimension; q++)
			{
				Faces[i].cubes[p*dimension+q].col = c[i];
				Faces[i].cubes[p*dimension+q].texture = texture[(i*6+p%3)*3+(q%3)];
				Faces[i].cubes[p*dimension+q].rotateAngle = 0;
			}
	}
}

void Cube::buildList()
{
	this->dspList=glGenLists(1);
	glNewList(dspList, GL_COMPILE);

	glBegin(GL_QUADS);

	glTexCoord2f(0.f,1.f);
	glVertex3f(-0.5f*0.9/dimension,0.5f*0.9/dimension,0.f);

	glTexCoord2f(0.f,0.f);
	glVertex3f(-0.5f*0.9/dimension,-0.5f*0.9/dimension,0.f);

	glTexCoord2f(1.f,0.f);
	glVertex3f(0.5f*0.9/dimension,-0.5f*0.9/dimension,0.f);

	glTexCoord2f(1.f,1.f);
	glVertex3f(0.5f*0.9/dimension,0.5f*0.9/dimension,0.f);

	glEnd();

	glEndList();
}

void Cube::Click(int x, int y)
{
	Vx = (float)x/winW - 0.5;
	Vy = 0.5 - (float)y/winH;
}

void Cube::Drag(int X, int Y)
{
	Tx = (float)X/winW - 0.5;
	Ty = 0.5 - (float)Y/winH;
	float Mv = sqrt(Vx*Vx + Vy*Vy + .5*.5);
	float Mt = sqrt(Tx*Tx + Ty*Ty + .5*.5);
	float dot = Vx*Tx + Vy*Ty + .5*.5;
	Angle = 180*acos( dot/(Mv*Mt))/3.14159;
	x = Vy*(-.5) - (-.5)*Ty;
	y = (-.5)*Tx - Vx*(-.5);
	z = Vx*Ty - Vy*Tx;

//	elevation+= acos(Ty) - acos(Vy);
//	azimuth+= acos(Tx*Vx+.5*.5);

	Vx = Tx;
	Vy = Ty;
}

void Cube::Render()
{	
	if(abs(Angle)>1E-9){
		glRotatef(-Angle,x,y,z);
	}

//	glRotatef(elevation,0,1,0);
//	glRotatef(azimuth,1,0,0);
	for(int i=0;i<6;i++)
	{
		for(unsigned int p=0;p<dimension;p++)
		{
			for(unsigned int q=0;q<dimension;q++)
			{
				glPushMatrix();	
				if(bAnimated)
				{
					if(numScramble==0)
						bAnimated = false;
					else
					{
						if (animatedAngle>=90 && ! bPaused)
						{
							singleMove(moves[numScramble-1].slice,!(moves[numScramble-1].direction),moves[numScramble-1].axis);
							numScramble--;
							animatedAngle-=90;
						}
						unsigned int s=moves[numScramble-1].slice;
						unsigned int d=moves[numScramble-1].direction;
						unsigned int a=moves[numScramble-1].axis;
						if	( (	a ==0 && ( (i==RIGHT && s==dimension-1) || (i==LEFT && s==0) || ((i==FRONT || i==TOP || i==BUTTOM) && q==s) || (i==BACK && dimension-1-q==s)) )
							||( a ==1 && ( (i==TOP && s==0) || (i==BUTTOM && s==dimension-1) || ((i==FRONT || i==BACK || i==LEFT || i==RIGHT) && p==s) ))
							||( a ==2 && ( (i==FRONT && s==0) || (i==BACK && s==dimension-1) || (i==RIGHT && q==s) || (i==LEFT && dimension-1-q==s) || (i==TOP && dimension-1-p==s) || (i==BUTTOM && p==s)  )) 
							)
						{
							int sign = d>0?-1:1;
							switch(a)
							{
							case 0:
								glRotatef(sign*animatedAngle,1,0,0);
								break;
							case 1:
								glRotatef(sign*animatedAngle,0,1,0);
								break;
							case 2:
								glRotatef(sign*animatedAngle,0,0,1);
							}
						}
					}
				}

				switch(i)
				{
				case 1:
					glRotatef(180,0,1,0);
					break;
				case 2:
					glRotatef(-90,0,1,0);
					break;
				case 3:
					glRotatef(90,0,1,0);
					break;
				case 4:
					glRotatef(-90,1,0,0);
					break;
				case 5:
					glRotatef(90,1,0,0);
				}

				glTranslatef(-0.5+((float)q+0.5)/dimension,0.5-((float)p+0.5)/dimension,0.5f);
				glRotatef(Faces[i].cubes[p*dimension+q].rotateAngle,0,0,1);
				if(bTextured){
					glColor3f(1,1,1);
					glBindTexture(GL_TEXTURE_2D,Faces[i].cubes[p*dimension+q].texture);
				}
				else
					glColor3f(Faces[i].cubes[p*dimension+q].col.r,Faces[i].cubes[p*dimension+q].col.g,Faces[i].cubes[p*dimension+q].col.b);
				//glCallList(this->dspList);
	glBegin(GL_QUADS);

	glTexCoord2f(0.f,1.f);
	glVertex3f(-0.5f*0.9/dimension,0.5f*0.9/dimension,0.f);

	glTexCoord2f(0.f,0.f);
	glVertex3f(-0.5f*0.9/dimension,-0.5f*0.9/dimension,0.f);

	glTexCoord2f(1.f,0.f);
	glVertex3f(0.5f*0.9/dimension,-0.5f*0.9/dimension,0.f);

	glTexCoord2f(1.f,1.f);
	glVertex3f(0.5f*0.9/dimension,0.5f*0.9/dimension,0.f);

	glEnd();

				glPopMatrix();
			}
		}
	}
}

void Cube::reset()
{
	Color c[] = {{1.f,0.5f,0}, {1.f,0,0},{0,1.f,0} , {1.f,1.f,0}, {1.f,1.f,1.f}, {0,0,1.f}}; 
	for(int i=0; i<6; i++)
	{
		for(unsigned int p=0; p<dimension; p++)
			for(unsigned int q=0; q<dimension; q++)
			{
				Faces[i].cubes[p*dimension+q].col = c[i];
				Faces[i].cubes[p*dimension+q].texture = this->texture[(i*6+p%3)*3+(q%3)];
				Faces[i].cubes[p*dimension+q].rotateAngle = 0;
			}
	}
}

void Cube::scramble()
{
	if(moves==NULL)
	{
		moves = new Movement[scramble_moves];
	}
	else
	{
		Movement* temp = new Movement[numScramble+scramble_moves];
		for(int i=0; i<numScramble; i++)
			temp[i] = moves[i];
		delete moves;
		moves = temp;
	}
	for(unsigned int i=numScramble; i<numScramble+scramble_moves; i++)
	{
		moves[i].set(rand()%dimension,rand()%2,rand()%2);//3);
		singleMove(moves[i].slice, moves[i].direction, moves[i].axis);
	}
	numScramble += scramble_moves;
}

void Cube::singleMove(unsigned int s, unsigned int d, unsigned int a)
{
	SubCube C;	
	Facet temp;
	temp.Creat(dimension);
	unsigned int i,j;
	switch(a)
	{
	case 0: //x
		if(d)
		{
			for(i=0;i<dimension;i++){
				C = Faces[FRONT].cubes[i*dimension+s];
				Faces[FRONT].cubes[i*dimension+s] = Faces[TOP].cubes[i*dimension+s];
				Faces[TOP].cubes[i*dimension+s]=Faces[BACK].cubes[(dimension-1-i)*dimension+(dimension-1-s)];
				Faces[BACK].cubes[(dimension-1-i)*dimension+(dimension-1-s)]=Faces[BUTTOM].cubes[i*dimension+s];
				Faces[BUTTOM].cubes[i*dimension+s] = C;
			}
		}
		else
		{
			for(i=0;i<dimension;i++){
				C = Faces[FRONT].cubes[i*dimension+s];
				Faces[FRONT].cubes[i*dimension+s] = Faces[BUTTOM].cubes[i*dimension+s];
				Faces[BUTTOM].cubes[i*dimension+s] = Faces[BACK].cubes[(dimension-1-i)*dimension+(dimension-1-s)];
				Faces[BACK].cubes[(dimension-1-i)*dimension+(dimension-1-s)]=Faces[TOP].cubes[i*dimension+s];
				Faces[TOP].cubes[i*dimension+s]=C;
			}
		}
		if(s==0)
		{
			if(d)
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[LEFT].cubes[i].rotateAngle-=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[j*dimension+(dimension-1-i)]=Faces[LEFT].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[LEFT].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
			else
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[LEFT].cubes[i].rotateAngle+=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[(dimension-1-j)*dimension+i]=Faces[LEFT].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[LEFT].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
		}
		else if(s==dimension-1)
		{
			if(d)
			{
				for(i=0;i<dimension*dimension; i++)
					Faces[RIGHT].cubes[i].rotateAngle+=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[(dimension-1-j)*dimension+i]=Faces[RIGHT].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[RIGHT].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
			else
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[RIGHT].cubes[i].rotateAngle-=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[j*dimension+(dimension-1-i)]=Faces[RIGHT].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[RIGHT].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
		}
		break;
	case 1: //y
		if(d)
		{
			for(i=0;i<dimension;i++){
				C = Faces[FRONT].cubes[s*dimension+i];
				Faces[FRONT].cubes[s*dimension+i] = Faces[LEFT].cubes[s*dimension+i];
				Faces[LEFT].cubes[s*dimension+i]=Faces[BACK].cubes[s*dimension+i];
				Faces[BACK].cubes[s*dimension+i]=Faces[RIGHT].cubes[s*dimension+i];
				Faces[RIGHT].cubes[s*dimension+i] = C;
			}
		}
		else
		{
			for(i=0;i<dimension;i++){
				C = Faces[FRONT].cubes[s*dimension+i];
				Faces[FRONT].cubes[s*dimension+i] = Faces[RIGHT].cubes[s*dimension+i];
				Faces[RIGHT].cubes[s*dimension+i]=Faces[BACK].cubes[s*dimension+i];
				Faces[BACK].cubes[s*dimension+i]=Faces[LEFT].cubes[s*dimension+i];
				Faces[LEFT].cubes[s*dimension+i] = C;
			}
		}
		if(s==0)
		{
			if(d)
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[TOP].cubes[i].rotateAngle+=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[(dimension-1-j)*dimension+i]=Faces[TOP].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[TOP].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
			else
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[LEFT].cubes[i].rotateAngle-=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[j*dimension+(dimension-1-i)]=Faces[TOP].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[TOP].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
		}
		else if(s==dimension-1)
		{
			if(d)
			{
				for(i=0;i<dimension*dimension; i++)
					Faces[BUTTOM].cubes[i].rotateAngle-=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[j*dimension+(dimension-1-i)]=Faces[BUTTOM].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[BUTTOM].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
			else
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[BUTTOM].cubes[i].rotateAngle+=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[(dimension-1-j)*dimension+i]=Faces[BUTTOM].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[BUTTOM].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
		}
		break;
	case 2: //z
		if(d)
		{
			for(i=0;i<dimension;i++){
				C = Faces[RIGHT].cubes[i*dimension+s];
				Faces[RIGHT].cubes[i*dimension+s] = Faces[BUTTOM].cubes[s*dimension+(dimension-1-i)];
				Faces[BUTTOM].cubes[s*dimension+(dimension-1-i)]=Faces[LEFT].cubes[(dimension-1-i)*dimension+(dimension-1-s)];
				Faces[LEFT].cubes[(dimension-1-i)*dimension+(dimension-1-s)]=Faces[TOP].cubes[(dimension-1-s)*dimension+i];
				Faces[TOP].cubes[(dimension-1-s)*dimension+i] = C;
			}
		}
		else
		{
			for(i=0;i<dimension;i++){
				C = Faces[RIGHT].cubes[i*dimension+s];
				Faces[RIGHT].cubes[i*dimension+s] = Faces[TOP].cubes[(dimension-1-s)*dimension+i];
				Faces[TOP].cubes[(dimension-1-s)*dimension+i]=Faces[LEFT].cubes[(dimension-1-i)*dimension+(dimension-1-s)];
				Faces[LEFT].cubes[(dimension-1-i)*dimension+(dimension-1-s)]=Faces[BUTTOM].cubes[s*dimension+(dimension-1-i)];
				Faces[BUTTOM].cubes[s*dimension+(dimension-1-i)] = C;
			}
		}
		if(s==0)
		{
			if(d)
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[FRONT].cubes[i].rotateAngle+=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[(dimension-1-j)*dimension+i]=Faces[FRONT].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[FRONT].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
			else
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[FRONT].cubes[i].rotateAngle-=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[j*dimension+(dimension-1-i)]=Faces[FRONT].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[FRONT].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
		}
		else if(s==dimension-1)
		{
			if(d)
			{
				for(i=0; i<dimension*dimension; i++)
					Faces[BACK].cubes[i].rotateAngle-=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[j*dimension+(dimension-1-i)]=Faces[BACK].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[BACK].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
			else
			{
				for(i=0;i<dimension*dimension; i++)
					Faces[BACK].cubes[i].rotateAngle+=90;
				for(i=0; i<dimension; i++)
					for(j=0; j<dimension; j++)
						temp.cubes[(dimension-1-j)*dimension+i]=Faces[BACK].cubes[i*dimension+j];
				for(i=0;i<dimension;i++)
					for(j=0;j<dimension;j++)
						Faces[BACK].cubes[i*dimension+j] = temp.cubes[i*dimension+j];
			}
		}
		break;
	}
}

void Cube::ToggleTexturing()
{
	bTextured = ! bTextured;
	if(bTextured)
		glEnable(GL_TEXTURE_2D);
	else
		glDisable(GL_TEXTURE_2D);
}
void Cube::WindowWidth( int w, int h )
{
	winW=w;
	winH=h;
}

Cube::~Cube()
{
	if(moves!=NULL)
		delete moves;
	moves = NULL;
}

void Cube::next()
{
	if(numScramble>0)
	{
		singleMove(moves[numScramble-1].slice,!(moves[numScramble-1].direction),moves[numScramble-1].axis);
		numScramble--;
	}
}

void Cube::step()
{
	static int n=0;
	if(n<numScramble){
		singleMove(moves[n].slice,moves[n].direction,moves[n].axis);
		n++;
	}
}