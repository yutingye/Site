#ifndef _CUBE_H 
#define _CUBE_H

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <iostream>

struct Color{
	float r, g, b;
};

struct SubCube{
	float rotateAngle;
	GLuint texture;
	Color col;
	void operator = (const SubCube& c)
	{
		rotateAngle = c.rotateAngle;
		texture = c.texture;
		col = c.col;
	}
};

struct Facet{
	SubCube* cubes;
	void Creat(int n){cubes = new SubCube[n*n];}
	~Facet(){if(cubes != NULL) delete cubes;}
};

struct Movement{
	unsigned int slice;
	unsigned int direction;
	unsigned int axis;
	void set(unsigned int s, unsigned int d, unsigned int a)
	{
		slice = s;
		direction = d;
		axis = a;
	}
	void operator = (const Movement&m)
	{
		slice = m.slice;
		direction = m.direction;
		axis = m.axis;
	}
};

enum faces
{FRONT, BACK, LEFT, RIGHT, TOP, BUTTOM};

class Cube
{
private:
	unsigned int dimension;
	unsigned int scramble_moves;
	float turn_time;

	int winW;
	int winH;

	float Vx;
	float Vy;
	float Tx;
	float Ty;

	float elevation, azimuth;

	float x,y,z,Angle;

	float animatedAngle;

	bool bTextured;
	bool bAnimated;
	bool bPaused;

	GLuint texture[54];
	char texBuff[256*256*3];
	GLuint dspList;
	Facet Faces[6];
	Movement* moves;
	int numScramble;

public:
	Cube(float t, unsigned int d, unsigned int s);
	~Cube();
	void buildList();
	void Render();
	void Click( int x, int y );
	void Drag( int x, int y );
	void ToggleTexturing();
	void scramble();
	void singleMove(unsigned int s, unsigned int d, unsigned int a);
	void reset();
	void next();
	void step();
	void setAngle(float a){animatedAngle += a ;}
	void setAnimated(bool s){bAnimated = s;}
	void setPaused(bool p){bPaused = p;}
	void WindowWidth( int w, int h );
	bool isAnimated(){return bAnimated;}
	bool isPaused(){return bPaused;}
};

#endif