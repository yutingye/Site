#include <iostream>

using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "argparser.h"

	static char *
	Strdup(const char *c2) 
	{
		char *ret = 0;
		if (c2) 
		{
			ret = new char[strlen(c2) + 1];
			strcpy(ret, c2);
		}
		return ret;
	}

	class Arg {
	  public:
		Arg(const char *sw, bool req, int n);
		virtual ~Arg();

		virtual void set(int index, const char *str) = 0;

		virtual bool Process(char **&argv);

		const char *get_switch() const { return c_switch; }
		bool RequiredButNotSet() const { return Required && !valSet; }
    
		Arg *next;

	  protected:
		char *c_switch;
		int num;
		bool Required, valSet;
	};

	Arg::Arg(const char *sw, bool req, int n)
	{
		c_switch = new char[strlen(sw) + 2];
		c_switch[0] = '\0';
		strcat(c_switch, "-");
		strcat(c_switch, sw);
		Required = req;
		valSet = false;
		num = n;
		next = 0;
	}

	Arg::~Arg()
	{
		delete[] c_switch;
	}

	bool
	Arg::Process(char **&argv) 
	{
		if (!strcmp(argv[0], get_switch())) 
		{
			for (int i = 0; i < num; i++) 
			{
				argv++;
				if (!argv[0]) 
				{
					cerr << "Not enough arguments for \"" << get_switch() << "\" switch." << endl;
					exit(0);
				}
				set(i, *argv);
			}
			++argv;
			valSet = true;
			return true;
		}
		return false;
	}

	class IntArg : public Arg 
	{
	public:
		IntArg(const char *sw, bool req, int num, int *i)
			: Arg(sw, req, num), ptr(i) { }
	
		void set(int index, const char *str) { ptr[index] = atoi(str); }

	private:
		int *ptr;
	};

	class UIntArg : public Arg 
	{
	public:
		UIntArg(const char *sw, bool req, int num, unsigned int *i)
			: Arg(sw, req, num), ptr(i) { }
	
		void set(int index, const char *str) { ptr[index] = atoi(str); }

	private:
		unsigned int *ptr;
	};

	class DoubleArg : public Arg {
	public:
		DoubleArg(const char *sw, bool req,
			  int num, double *d)
			: Arg(sw, req, num), ptr(d) { }

		void set(int index, const char *str) { ptr[index] = atof(str); }

	private:
		double *ptr;
	};

	class FloatArg : public Arg {
	public:
		FloatArg(const char *sw, bool req,
			 int num, float *f)
			: Arg(sw, req, num), ptr(f) { }

		void set(int index, const char *str) { ptr[index] = (float) atof(str); }

	private:
		float *ptr;
	};

	class StringArg : public Arg {
	public:
		StringArg(const char *sw, bool req, 
			  int num, char **str)
			: Arg(sw, req, num), ptr(str) { } 

		void set(int index, const char *str) 
		  { ptr[index] = Strdup(str); }

	private:
		char **ptr;
	};

	class BoolArg : public Arg {
	public:
		BoolArg(const char *sw, bool *b)
			: Arg(sw, false, 1), ptr(b) { }

		bool Process(char **&argv);
		void set(int , const char *) { *ptr = !*ptr; }

	private:
		bool *ptr;
	};

	bool
	BoolArg::Process(char **&argv) 
	{
		if (!strcmp(argv[0], get_switch())) 
		{
			*ptr = !*ptr;
			argv++;
			valSet = true;
			return true;
		}
		return false;
	}

	ArgParser::ArgParser() 
	{
		item_list = 0;
	}

	ArgParser::~ArgParser() 
	{
		Arg *arg = item_list;
		while (arg) 
		{
			Arg *next = arg->next;
			delete arg;
			arg = next;
		}
	}

	void
	ArgParser::Optional(const char *c, 
				int *i, int num) 
	{
		Arg *a = new IntArg(c, false, num, i);
		add_arg(a);
	}

	void
	ArgParser::Optional(const char *c,
				unsigned int *i, int num) 
	{
		Arg *a = new UIntArg(c, false, num, i);
		add_arg(a);
	}

	void
	ArgParser::Optional(const char *c, 
				double *d, int num) 
	{
		Arg *a = new DoubleArg(c, false, num, d);
		add_arg(a);
	}

	void
	ArgParser::Optional(const char *c,
				float *f, int num) 
	{
		Arg *a = new FloatArg(c, false, num, f);
		add_arg(a);
	}

	void
	ArgParser::Optional(const char *c,
				char **str, int num) 
	{
		Arg *a = new StringArg(c, false, num, str);
		add_arg(a);
	}

	void
	ArgParser::Optional(const char *c, bool *b) 
	{
		Arg *a = new BoolArg(c, b);
		add_arg(a);
	}

 
	void
	ArgParser::Required(const char *c, 
				int *i, int num) 
	{
		Arg *a = new IntArg(c, true, num, i);
		add_arg(a);
	}

	void
	ArgParser::Required(const char *c,  
				unsigned int *i, int num) 
	{
		Arg *a = new UIntArg(c, true, num, i);
		add_arg(a);
	}

	void
	ArgParser::Required(const char *c, 
				double *d, int num) 
	{
		Arg *a = new DoubleArg(c, true, num, d);
		add_arg(a);
	}

	void
	ArgParser::Required(const char *c, 
				float *f, int num) 
	{
		Arg *a = new FloatArg(c, true, num, f);
		add_arg(a);
	}

	void
	ArgParser::Required(const char *c,
				char **str, int num) 
	{
		Arg *a = new StringArg(c, true, num, str);
		add_arg(a);
	}

	void 
	ArgParser::add_arg(Arg *a) 
	{
		Arg *arg = item_list;
		while (arg) 
		{
			if (!strcmp(a->get_switch(), arg->get_switch())) 
			{
				cerr << "Switch \"" << a->get_switch() << "\" is already taken!" << endl;
				exit(0);
			}
			arg = arg->next;
		}
		a->next = item_list;
		item_list = a;
	}

	void 
	ArgParser::Process(int, char **argv) 
	{
		argv++;
		while (*argv) 
		{
			Arg *arg = item_list;
			while (arg) 
			{
				if (arg->Process(argv))
				break;
				arg = arg->next;
			}
			if (!arg)
				argv++;
		}

		Arg *arg = item_list;
		bool some_missing = false;
		while (arg) 
		{
			if (arg->RequiredButNotSet()) 
			{
				some_missing = true;
				cerr << "-" << arg->get_switch() << " must be set" << endl;
			}
			arg = arg->next;
		}
		if (some_missing == true) {
			exit(1);
		}
	}
