#ifndef RUBIKS_ARGPARSER_H
#define RUBIKS_ARGPARSER_H

	class Arg;

	class ArgParser {
	public:
	  ArgParser();
	  ~ArgParser();

	  void Optional(const char *sw,
			int *i, int num=1);
	  void Optional(const char *sw, 
			unsigned int *i, int num=1);
	  void Optional(const char *sw, 
			double *d, int num=1);
	  void Optional(const char *sw, 
			float *f, int num=1);
	  void Optional(const char *sw, 
			char **str, int num=1);
	  void Optional(const char *sw, 
		    bool *b);

	  void Required(const char *sw, 
			int *i, int num=1);
	  void Required(const char *sw, 
			unsigned int *i, int num=1);
	  void Required(const char *sw,
			double *d, int num=1);
	  void Required(const char *sw,
			float *f, int num=1);
	  void Required(const char *sw,
			char **str, int num=1);

	  void Process(int argc, char **argv);

	private:
	  Arg *item_list;

	  void add_arg(Arg *a);
	};

#endif /* RUBIKS_ARGPARSER_H */
