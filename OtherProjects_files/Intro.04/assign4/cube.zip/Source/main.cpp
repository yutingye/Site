/*
#include "stdafx.h"
#include <iostream>
#include "argparser.h"
#include "timer.h"


using namespace std;

int main( int argc, char *argv[] )
{
	unsigned int dimension = 3;
	unsigned int scramble_moves = 20;
	float turn_time = .33f;

	ArgParser ap;

	ap.Optional( "t", &(turn_time) );
	ap.Optional( "d", &(dimension) );
	ap.Optional( "m", &(scramble_moves) );
	ap.Process( argc, argv );

	cerr << "turn_time: " << turn_time << endl;
	cerr << "dimension: " << dimension << endl;
	cerr << "scramble_moves: " << scramble_moves << endl;

	cerr << endl << endl << "Running timer for 10 seconds (twice)" << endl;

	Timer t;
	int last_time = 0;
	bool first_run = true;

	int counter = 0;

	t.Start();
	for (;;)
	{
		// it's not a good idea to query the timer too often on Windows --
		// throws everything out of whack (time slows down about 2x)
		// So we'll check it every 1000 times through this loop. Isn't this
		// ridiculous?
		if ( (counter++)%1000 == 0)
		{
			double current_time = t.Time();
	
			if ( (int) current_time != last_time )
			{
				cerr << (int) current_time << " seconds" << endl;
				last_time = (int) current_time;
			}
			if (last_time == 10)
			{
				if (first_run)
				{
					t.Reset();
					t.Start();
					first_run = false;
				}
				else
				{
					break;
				}
			}
		}
	}

	return 0;
}
*/

#include "argparser.h"
#include "timer.h"
#include "Cube.h"


Cube *theCube;
Timer t;
float turn_time = 1.f;
double last_time=0;

void display( void )
{
	glClear( GL_DEPTH_BUFFER_BIT );	
	glClear( GL_COLOR_BUFFER_BIT );
	theCube->Render();
	glutSwapBuffers();
}

void initgl(void)
{
	glClearColor( 0, 0, 0, 0);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glEnable(GL_DEPTH_TEST);
}

void reshape( int w, int h )
{
	static int first = 1;
	if (first)
	{
		first = 0;
		initgl();
	}
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	
	gluPerspective(40,(GLfloat) w/(GLfloat) h, 1,5);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glViewport( 0, 0, w, h );	

	theCube->WindowWidth(w,h);
	glLoadIdentity();
	glTranslatef(0,0,-2.5f);
	glutPostRedisplay();
}

void keyboard( unsigned char key, int x, int y )
{
	if (key == 27) // ESC
	{
		exit(0);
	}
	if (key == 't' || key == 'T')
	{
		theCube->ToggleTexturing();
	}
	if (key == 's' || key == 'S')
	{
		theCube->scramble();
	}
	if (key == 'r' || key == 'R')
	{
		theCube->reset();
	}
	if(key == 'f' || key == 'F')
	{
		theCube->setAnimated(true);
		last_time = ::t.Time();
	}
	if(key=='p' || key == 'P')
	{
		if(theCube->isPaused())
		{
			theCube->setPaused(false);
			::t.Start();
			last_time = ::t.Time();
		}
		else
		{
			theCube->setPaused(true);
			::t.Stop();
		}
	}
	if(key == 'n' || key == 'N')
	{
		theCube->next();
	}
	if(key == 'e' || key =='E')
		theCube->step();
	glutPostRedisplay();
}

static bool doing_it = false;

void mouse( int button, int state, int x, int y )
{
	if (button == GLUT_LEFT && state == GLUT_DOWN)
	{
		theCube->Click( x, y );
		doing_it = true;
	}
	else doing_it = false;
	glutPostRedisplay();
}

void motion( int x, int y )
{
	if (doing_it)
	{
		theCube->Drag( x, y );
		glutPostRedisplay();
	}
}
void idle()
{	
	static int count=0;
	if((count++)%1000==0){ 
		if(theCube->isAnimated())
		{
			double current_time = ::t.Time();
			if(theCube->isPaused())
				return;
			theCube->setAngle(90*(current_time-last_time)/::turn_time);
			last_time = current_time;
			glutPostRedisplay();
		}
	}
}

int main (int argc, char *argv[]) {
	
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE );
	glutInitWindowSize( 500, 500 );
	
	glutCreateWindow( "Rubik's Cube" );
	
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );
	glutKeyboardFunc( keyboard );
	glutMouseFunc( mouse );
	glutMotionFunc( motion );
	glutIdleFunc( idle );

	unsigned int dimension = 3;
	unsigned int scramble_moves = 20;


	ArgParser ap;

	ap.Optional( "t", &(turn_time) );
	ap.Optional( "d", &(dimension) );
	ap.Optional( "m", &(scramble_moves) );
	ap.Process( argc, argv );
	
	theCube = new Cube(turn_time, dimension, scramble_moves);
	::t.Start();
	glutMainLoop();
}
