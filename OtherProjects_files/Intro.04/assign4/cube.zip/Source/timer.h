#ifndef RUBIKS_TIMER_H
#define RUBIKS_TIMER_H

#if defined( _unix )
#include <sys/time.h>
#elif defined( _WIN32 )
#include <windows.h>
#endif

	class Timer {
	public:
		Timer();
		~Timer();

		void Start();
		void Stop();
		void Reset();

		double Time();

	private:
		double time0, elapsed;
		bool running;
		double GetTime();

#if defined( __sgi )
		int fd;
		unsigned long long counter64;
		unsigned int counter32;
		unsigned int cycleval;

		typedef unsigned long long iotimer64_t;
		typedef unsigned int iotimer32_t;
		volatile iotimer64_t *iotimer_addr64;
		volatile iotimer32_t *iotimer_addr32;

		void *unmapLocation;
		int unmapSize;
#elif defined( _WIN32 )
		LARGE_INTEGER performance_counter, performance_frequency;
		double one_over_frequency;
#elif defined( _unix )
		struct timeval timeofday;
#endif
	};

#endif /* RUBIKS_TIMER_H */
