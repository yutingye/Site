#include <stdio.h>
#include <stdlib.h>

#include "bmp.h"

int LoadBMP(char *filename, Image *image)
{
    FILE *file;
    unsigned long size;        // size of the image in bytes.
    unsigned long i;           // standard counter.
    unsigned short int planes; // number of planes in image (must be 1) 
    unsigned short int bpp;    // number of bits per pixel (must be 24)
    char temp;                 // temporary color storage for bgr-rgb conversion.
    
    // The job of this code is to
    // load in a bitmap file. If the file doesn't exist NULL is sent back
    // meaning the texture couldn't be loaded. Before I start explaining the
    // code there are a few VERY important things you need to know about the
    // images you plan to use as textures. The image height and width MUST be a
    // power of 2. The width and height must be at least 64 pixels, and for
    // compatibility reasons, shouldn't be more than 256 pixels. If the image
    // you want to use is not 64, 128 or 256 pixels on the width or height,
    // resize it in an art program. There are ways around this limitation, but
    // for now we'll just stick to standard texture sizes. 
    
    // make sure the file is there.
    
    if ((file = fopen(filename, "rb"))==NULL) {
        printf("File Not Found : %s\n",filename);
        return 0;
    }
    
    // seek through the bmp header, up to the width/height:
    fseek(file, 18, SEEK_CUR);
    
    // No 100% errorchecking anymore!!!
    
    // read the width
    fread(&image->sizeX, sizeof(int), 1, file);
    printf("Width of %s: %lu\n", filename, image->sizeX);
    
    // read the height
    fread(&image->sizeY, sizeof(int), 1, file);
    printf("Height of %s: %lu\n", filename, image->sizeY);
    
    // calculate the size (assuming 24 bits or 3 bytes per pixel).
    size = image->sizeX * image->sizeY * 4;
    
    // read the planes
    fread(&planes, sizeof(short), 1, file);
    if (planes != 1) {
        printf("Planes from %s is not 1: %u\n", filename, planes);
        return 0;
    }
    
    // read the bpp
    fread(&bpp, sizeof(short), 1, file);
    if (bpp != 24) {
        printf("Bpp from %s is not 24: %u\n", filename, bpp);
        return 0;
    }
    
    // seek past the rest of the bitmap header.
    fseek(file, 24, SEEK_CUR);
    
    // read the data. 
    image->pixels = (unsigned char *) malloc(size);
    if (image->pixels == NULL) {
        printf("Error allocating memory for color-corrected image data");
        return 0;
    }
    
    for (i=0;i<size;i+=4) { // reverse all of the colors. (bgr -> rgb)
        if (fread(&image->pixels[i], 3, 1, file) != 1) {
            printf("Error reading image data from %s.\n", filename);
            return 0;
        }
        temp = image->pixels[i];
        image->pixels[i] = image->pixels[i+2];
        image->pixels[i+2] = temp;
        image->pixels[i+3] = 255;
    }
    
    // we're done.
    return 1;
}