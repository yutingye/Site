#ifndef H_BMP_H
#define H_BMP_H
//=============================================================================

struct Image {
    unsigned long sizeX;
    unsigned long sizeY;
    unsigned char *pixels;
};

int LoadBMP(char *filename, Image *image);
//=============================================================================
#endif // Uniqueness IFNDEF