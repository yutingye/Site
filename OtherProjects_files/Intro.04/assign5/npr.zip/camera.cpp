///////////////////////////////////////////////////////////////////////////////
//// Includes /////////////////////////////////////////////////////////////////
#include "camera.h"

#define _USE_MATH_DEFINES
#include <math.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>

///////////////////////////////////////////////////////////////////////////////
//// Constants ////////////////////////////////////////////////////////////////
const float DEG2RAD = (float)M_PI/180.0f;

///////////////////////////////////////////////////////////////////////////////
//// Functions ////////////////////////////////////////////////////////////////

/*
================
GetVectors

Puts the up, right, and forward vectors in the corresponding arrays
===============
*/
void CCamera::GetVectors(float up[], float right[], float forward[])
{
	switch(this->mode)
	{
	case CM_FLY:
		up[0] = -1.0f*sinf(DEG2RAD*this->fAngle[0])*sinf(DEG2RAD*this->fAngle[1]);
		up[1] = cosf(DEG2RAD*this->fAngle[0]);
		up[2] = sinf(DEG2RAD*this->fAngle[0])*cosf(DEG2RAD*this->fAngle[1]);

		right[0] = cosf(DEG2RAD*this->fAngle[1]);
		right[1] = 0.0f;
		right[2] = sinf(DEG2RAD*this->fAngle[1]);

		forward[0] = cosf(DEG2RAD*this->fAngle[0])*sinf(DEG2RAD*this->fAngle[1]);
		forward[1] = sinf(DEG2RAD*this->fAngle[0]);
		forward[2] = -1.0f*cosf(DEG2RAD*this->fAngle[0])*cosf(DEG2RAD*this->fAngle[1]);
		break;

	case CM_ORBIT:		
		up[0] = -1.0f*sinf(DEG2RAD*this->fAngle[0])*sinf(DEG2RAD*this->fAngle[1]);
		up[1] = cosf(DEG2RAD*this->fAngle[0]);
		up[2] = sinf(DEG2RAD*this->fAngle[0])*cosf(DEG2RAD*this->fAngle[1]);

		right[0] = -1.0f*cosf(DEG2RAD*this->fAngle[1]);
		right[1] = 0.0f;
		right[2] = -1.0f*sinf(DEG2RAD*this->fAngle[1]);

		forward[0] = -1.0f*cosf(DEG2RAD*this->fAngle[0])*sinf(DEG2RAD*this->fAngle[1]);
		forward[1] = -1.0f*sinf(DEG2RAD*this->fAngle[0]);
		forward[2] = cosf(DEG2RAD*this->fAngle[0])*cosf(DEG2RAD*this->fAngle[1]);
	}
}

/*
================
GetEyePosition

Puts the eye position in the vector
===============
*/
void CCamera::GetEyePosition(float EyePos[])
{
	float	EyeDir[3];

	switch(this->mode)
	{
		case CM_FLY:
			EyePos[0] = this->fPosition[0];
			EyePos[1] = this->fPosition[1];
			EyePos[2] = this->fPosition[2];
			break;
					
		case CM_ORBIT:
			EyeDir[0] = cosf(DEG2RAD*this->fAngle[0])*sinf(DEG2RAD*this->fAngle[1]);
			EyeDir[1] = sinf(DEG2RAD*this->fAngle[0]);
			EyeDir[2] = -1.0f*cosf(DEG2RAD*this->fAngle[0])*cosf(DEG2RAD*this->fAngle[1]);

			EyePos[0] = this->fRadius*EyeDir[0] + this->fPosition[0];
			EyePos[1] = this->fRadius*EyeDir[1] + this->fPosition[1];
			EyePos[2] = this->fRadius*EyeDir[2] + this->fPosition[2];
			break;
	}
}

/*
================
SetViewMatrix

Sets the appropriate GL view matrix for the camera, given the current mode
===============
*/
void CCamera::SetViewMatrix()
{
	float EyePos[3];
	float up[3], right[3], forward[3];

	this->GetVectors(up, right, forward);

	// set up camera
	switch(this->mode)
	{
		case CM_FLY:
		gluLookAt(	this->fPosition[0], this->fPosition[1], this->fPosition[2], 
					this->fPosition[0]+forward[0], this->fPosition[1]+forward[1], this->fPosition[2]+forward[2], 
					up[0], up[1], up[2]);
		break;

	case CM_ORBIT:
		this->GetEyePosition(EyePos);
		gluLookAt(	EyePos[0], EyePos[1], EyePos[2], 
					this->fPosition[0], this->fPosition[1], this->fPosition[2], 
					up[0], up[1], up[2]);
		break;
	}
}