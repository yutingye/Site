#ifndef H_CAMERA_H
#define H_CAMERA_H
//=============================================================================

///////////////////////////////////////////////////////////////////////////////
//// Constants ////////////////////////////////////////////////////////////////
enum	CamMode_e {CM_FLY, CM_ORBIT};
///////////////////////////////////////////////////////////////////////////////
//// Structures ///////////////////////////////////////////////////////////////
class CCamera
{
public:
	CCamera() {};

	void GetVectors(float up[], float right[], float forward[]);
	void GetEyePosition(float EyePos[]);
	void SetViewMatrix();

	CamMode_e	mode;
	float		fPosition[3];
	float		fAngle[3];
	float		fRadius;
};

//=============================================================================
#endif // Uniqueness IFNDEF
