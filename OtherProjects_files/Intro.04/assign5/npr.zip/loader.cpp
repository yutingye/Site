/*	Assignment 2 -- Clipping
================================================================================
	loader.cpp

		Model loader helper functions
================================================================================
*/

////////////////////////////////////////////////////////////////////////////////
//// Includes //////////////////////////////////////////////////////////////////
#include "loader.h"

#include <iostream>
#include <fstream>
#include <cstring>
//#include <string>
using namespace std;

//extern CCamera g_Camera;
//extern int			inumSil;
////////////////////////////////////////////////////////////////////////////////
//// Functions /////////////////////////////////////////////////////////////////
//--------------------------------
// LoadModel
//		Loads a poly model from the specified filename.
//	Returns a pointer to the model on success, or NULL on failure.
SPolyModel *LoadPolyModel(const char szFilename[])
{
	SPolyModel *pModel;
	SVertex	*pCurrVert;
	SFace	*pCurrFace;
//	string sBuff;
	char	szBuff[80];
	ifstream fin;

	int	iCurrVert, iCurrFace;

	fin.open(szFilename);

	if (fin.is_open())
	{
		pModel = new SPolyModel;
		fin >> szBuff;
		if (!stricmp(szBuff, "vertices:"))
			fin >> pModel->iNumVerts;
		else
		{
			cout << "Error: Model \"" << szFilename << "\" not of expected format." << endl;
			delete pModel;
			return NULL;
		}

		fin >> szBuff;
		if (!stricmp(szBuff, "faces:"))
			fin >> pModel->iNumFaces;
		else
		{
			cout << "Error: Model \"" << szFilename << "\" not of expected format." << endl;
			delete pModel;
			return NULL;
		}

		pModel->pVerts = new SVertex[pModel->iNumVerts];
		pModel->pFaces = new SFace[pModel->iNumFaces];

		iCurrVert = 0;
		iCurrFace = 0;
		while (fin >> szBuff)
		{
			if (szBuff[0] == 'v')
			{
				pCurrVert = &pModel->pVerts[iCurrVert++];
				fin	>> pCurrVert->vPosition[0]
					>> pCurrVert->vPosition[1]
					>> pCurrVert->vPosition[2]
					>> pCurrVert->vNormal[0]
					>> pCurrVert->vNormal[1]
					>> pCurrVert->vNormal[2];
			}
			else if (szBuff[0] == 'f')
			{
				pCurrFace = &pModel->pFaces[iCurrFace++];
				fin	>> pCurrFace->iVerts[0]
					>> pCurrFace->iVerts[1]
					>> pCurrFace->iVerts[2];
				--pCurrFace->iVerts[0];
				--pCurrFace->iVerts[1];
				--pCurrFace->iVerts[2];
			}
			else
			{
				cout << "Error: Model \"" << szFilename << "\" not of expected format." << endl;
				FreePolyModel(pModel);
				return NULL;
			}
		}
		fin.close();
		return pModel;
	}
	else
	{
		cout << "Error: Could not load model \"" << szFilename << "\"" << endl;
		return NULL;
	}
}

//--------------------------------
// FreePolyModel
//		Deallocates the specified model.
void	FreePolyModel(SPolyModel *pModel)
{
	if (pModel)
	{
		delete [] pModel->pVerts;
		delete [] pModel->pFaces;
		delete pModel;
	}
}

/*
SConnect   *BuildConnect(SPolyModel Model)
{
	SConnect *con = new SConnect[Model.iNumFaces*3];
	for(int i=0;i<Model.iNumFaces;i++)
	{
		for(j=0;j<3;j++){
			int idx1 = Model.pFaces[i].iVerts[j];
			int idx2 = Model.pFaces[i].iVerts[(j+1)%3];
			con[idx1<idx2?idx1:idx2].addNeighbor(idx1>idx2?idx1:idx2,i);
		}
	}
}

SSils      *DetectEdge(SConnect* Con, SPolyModel Model)
{
	Vec3f vert1,vert2,vert3,cross[2],forw;
	float up[3],right[3],forward[3];
	forw.x = forward[0];
	forw.y = forward[1];
	forw.z = forward[2];

	g_Camera.GetVectors(up,right,forward);

//	new 

	for(int i=0; i<Model.iNumFaces*3; i++)
	{
		for(int j=0; j<Con[i].curr_length;j++)
		{
			for(int p=0;p<Model.pFaces[Con[i].neighbors[j].i;p++)
			{
				vert1.x = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[0]].vPosition[0];
				vert1.y = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[0]].vPosition[1];
				vert1.z = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[0]].vPosition[2];
				
				vert2.x = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[1]].vPosition[0];
				vert2.y = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[1]].vPosition[1];
				vert2.z = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[1]].vPosition[2];

				vert3.x = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[2]].vPosition[0];
				vert3.y = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[2]].vPosition[1];
				vert3.z = Model.pVerts[Model.pFaces[Con[i].neighbors[j].iFaces[0]].iVerts[2]].vPosition[2];

				VEC_sub(vert2,vert1);
				VEC_sub(vert1,vert3);
				VEC_cross(cross[p],vert1,vert2);
			}
			if(p==2 && VEC_dot(cross[0],forw)*VEC_dot(cross[1],forw)<0)

		}
	}
}
*/