/*	Assignment 2 -- Clipping
================================================================================
	loader.h

		Declaration for model loader structures and functions
================================================================================
*/
#ifndef LOADER_H
#define LOADER_H


//==============================================================================
////////////////////////////////////////////////////////////////////////////////
//// Structs ///////////////////////////////////////////////////////////////////
struct SVertex
{
	float	vPosition[3];	// The X, Y, and Z coordinates of this vertex
	float	vNormal[3];		// The normal in the X, Y, and Z direction
};

struct SFace
{
	int	iVerts[3];	// The indices of the vertices used by this face
};

struct	SPolyModel
{
	SVertex	*pVerts;	// Array of vertices used by the model
	SFace	*pFaces;	// Array of the faces used by the model
	int	iNumVerts;		// Number of vertices in the model 
	int iNumFaces;		// Number of faces in the model
};

/*

struct SNeighbor
{
	int iVerts;
	int iFaces[2];
	int i;
};

struct SConnect
{
	int max_length;
	int curr_length;
	SNeighbor* neighbors;

	SConnect ()
	{ max_length = 0; curr_length = 0; neighbors = 0; }

	void addNeighbor(int iV, int iF)
	{
		for(int i=0;i<curr_length;i++)
		{
			if(neighbors[i].iVerts == iV){
				neighbors[i].iFaces[i++] = iF;
				break;
			}
		}
		if(i == curr_length){
			if(curr_length==max_length){
				max_length+=5;
				SNeighbor *temp = new SNeighbor[max_length];
				for(int i=0;i<curr_length;i++)
					temp[i] = neighbors[i];
				delete [] neighbors;
				neighbors = temp;
			}
			neighbors[curr_length++].iVerts = iV;
			neighbors[curr_length].iFaces[0] = iF;
			neighbors[curr_length].i = 1;
		}
	}

	~SConnect()
	{ if(neighbors) delete []neighbors; }
};

struct SSils
{
	int iVerts[2];
};
*/
////////////////////////////////////////////////////////////////////////////////
//// Functions /////////////////////////////////////////////////////////////////
SPolyModel *LoadPolyModel(const char szFilename[]);
void		FreePolyModel(SPolyModel *pModel);
//SConnect   *BuildConnect(SPolyModel Model);
//SSils      *DetectEdge(SConnect Con);

//==============================================================================
#endif