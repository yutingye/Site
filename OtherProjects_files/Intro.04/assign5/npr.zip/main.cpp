//	Assignment 5 - NPR Rendering
////////////////////////////////////////////////////////////////////////////////
//// Libraries /////////////////////////////////////////////////////////////////
// NOTE: We must include these lines to make sure the project links properly

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glut32.lib")

////////////////////////////////////////////////////////////////////////////////
//// Includes //////////////////////////////////////////////////////////////////
//#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <gl/gl.h>		// OpenGL core library
#include <gl/glu.h>		// OpenGL internal utilities
#include <gl/glut.h>	// OpenGL Utility Toolkit

#include <iostream>
using namespace std;


#include "camera.h"
#include "loader.h"
#include "student.h"
#include "vec.h"

////////////////////////////////////////////////////////////////////////////////
//// Constants /////////////////////////////////////////////////////////////////
const float VIEW_FOV		= 90.0f;
const float	NEAR_PLANE		= 0.01f;
const float	FAR_PLANE		= 10.0f;


////////////////////////////////////////////////////////////////////////////////
//// Globals ///////////////////////////////////////////////////////////////////
// Viewport Dimensions
unsigned int	g_iWinHeight	= 768,
				g_iWinWidth		= 768;

// Camera
CCamera	g_Camera;
float	g_fRotSpeed	= 90.0f;

// Mouse stuff
int		g_iMouseButtons;
int		g_iMouseX;
int		g_iMouseY;

// Timing info
DWORD	g_dwLastFrame;
DWORD   g_dwForceStart;

// View info
SPolyModel	*g_pModels[5]   = {0, 0, 0, 0, 0};	//	The model data
int         g_iCurrModel = 0;
float       g_fNormalScale = 1.0f;  // Some models have backwards Normals
CNPRender   *g_pNPRender = NULL;
Vec3f       g_pLight;
int			g_outLine = 5;
int			inumSil;
bool g_text = false;
////////////////////////////////////////////////////////////////////////////////
//// Functions /////////////////////////////////////////////////////////////////

/*================================================================

						Useful Routines

================================================================*/
void DoExit()
{
    for (int i=0; i<5; ++i)
        free(g_pModels[0]);

    delete g_pNPRender;
	exit(0);
}
/*================================================================
				
						GLUT Callbacks

================================================================*/

/*
================================
CB_Display

Called by GLUT whenever the scene needs to be rendered
================================
*/
void CB_Display()
{
    float eye_pos[3];

	// Clear the back buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set state
	glEnable(GL_DEPTH_TEST);
	glColor3f(0.0f, 0.0, 0.0);
	//glEnable(GL_CULL_FACE);
	// Set a perspective projection
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(VIEW_FOV, 1.0f, NEAR_PLANE, FAR_PLANE);

	// Transform the modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    g_Camera.SetViewMatrix();
    g_Camera.GetEyePosition(eye_pos);

	// Render the scene
    g_pNPRender->DrawModel(g_pModels[g_iCurrModel], eye_pos);
    g_pNPRender->DrawModel(g_pModels[g_iCurrModel], eye_pos);
	// Swap the back buffer to the front
	glutSwapBuffers();
}

/*
================================
CB_Reshape

Called by GLUT when the window is resized
================================
*/
void CB_Reshape(int	iWidth, int iHeight)
{
	g_iWinWidth		= iWidth;
	g_iWinHeight	= max(iHeight, 1);

	// Resize the window in OpenGL
	glViewport(0, 0, g_iWinWidth, g_iWinHeight);
    glutPostRedisplay();
}

/*
================================
CB_Keyboard

Called by GLUT when a key is pressed
================================
*/
void CB_Keyboard(unsigned char key, int x, int y)
{
    key = tolower(key);
	switch (key)
	{
    case '1':
        g_iCurrModel = 0;
        break;

    case '2':
        if (g_pModels[1] == NULL)
        {
            cout << "Loading model. Please wait..." << endl;
            g_pModels[1] = LoadPolyModel("data/icos-unit.poly");
            if (g_pModels[1] == NULL)
            {
                cout << "Error! Could not open model. Exiting." << endl;
                exit(1);
            }
        }
        g_iCurrModel = 1;
        break;

    case '3':
        if (g_pModels[2] == NULL)
        {
            cout << "Loading model. Please wait..." << endl;
            g_pModels[2] = LoadPolyModel("data/tpot-unit.poly");
            if (g_pModels[2] == NULL)
            {
                cout << "Error! Could not open model. Exiting." << endl;
                exit(1);
            }
        }
        g_iCurrModel = 2;
        break;

    case '4':
        if (g_pModels[3] == NULL)
        {
            cout << "Loading model. Please wait..." << endl;
            g_pModels[3] = LoadPolyModel("data/penny3-unit.poly");
            if (g_pModels[3] == NULL)
            {
                cout << "Error! Could not open model. Exiting." << endl;
                exit(1);
            }
        }
        g_iCurrModel = 3;
        break;

    case '5':
        if (g_pModels[4] == NULL)
        {
            cout << "Loading model. Please wait..." << endl;
            g_pModels[4] = LoadPolyModel("data/bunny-unit.poly");
            if (g_pModels[4] == NULL)
            {
                cout << "Error! Could not open model. Exiting." << endl;
                exit(1);
            }
        }
        g_iCurrModel = 4;
        break;

	case '+':
	case '=':
		g_outLine++;
		break;

	case '-':
	case '_':
		g_outLine--;
		g_outLine = g_outLine<1?1:g_outLine;
		break;

	case 't':
	case 'T':
		g_text = ! g_text;
		if(g_text)
			glEnable(GL_TEXTURE_2D);
		else
			glDisable(GL_TEXTURE_2D);
		break;
	case 27:		// Escape key
		exit(0);
	}
    glutPostRedisplay();
}

/*
================================
CB_Special

Called by GLUT when a special key is pressed
================================
*/
void CB_Special(int key, int x, int y)
{
	int iMod = glutGetModifiers();
	float fRate = 0.025f;

	fRate = (iMod & GLUT_ACTIVE_SHIFT) ? fRate*2.0f : fRate;
	switch (key)
	{
	case GLUT_KEY_UP:
		g_Camera.fRadius -= fRate;
		break;
	
	case GLUT_KEY_DOWN:
		g_Camera.fRadius += fRate;
		break;	
	}
    glutPostRedisplay();
}

/*
================================
CB_Motion

Called by GLUT when mouse is dragged
================================
*/
void CB_Motion (int x, int y)
{
	float dX, dY;
	if (g_iMouseButtons == GLUT_RIGHT_BUTTON)
	{
		dX = (float)(x - g_iMouseX)/(float)g_iWinWidth;
		dY = (float)(y - g_iMouseY)/(float)g_iWinHeight;
		g_iMouseX = x;
		g_iMouseY = y;

		g_Camera.fAngle[1] -= g_fRotSpeed * dX;
		g_Camera.fAngle[0] -= g_fRotSpeed * dY;
	}
	if (g_iMouseButtons == GLUT_LEFT_BUTTON)
	{
		dX = (float)(x - g_iMouseX)/(float)g_iWinWidth;
		dY = (float)(y - g_iMouseY)/(float)g_iWinHeight;
		g_iMouseX = x;
		g_iMouseY = y;

		g_pLight.x -= g_fRotSpeed * dX;
		g_pLight.y -= g_fRotSpeed * dY;
	}
    glutPostRedisplay();
}

/*
================================
CB_Mouse

Called by GLUT when mouse button is pressed or released
================================
*/
void CB_Mouse (int button, int state, int x, int y)
{
	if (button == GLUT_RIGHT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			g_iMouseButtons = GLUT_RIGHT_BUTTON;
			g_iMouseX = x;
			g_iMouseY = y;
		}
		else
			g_iMouseButtons = 0;
	}
    else if (button == GLUT_LEFT_BUTTON)
    {
		if (state == GLUT_DOWN)
        {
            g_iMouseButtons = GLUT_LEFT_BUTTON;
			g_iMouseX = x;
			g_iMouseY = y;
            CB_Motion(x, y);
        }
        g_iMouseButtons = 0;
    }
    glutPostRedisplay();
}

/*================================================================

						MAIN Entrypoint

================================================================*/
int main(int argc, char *argv[])
{
    AllocConsole();

	// Initialize the GLUT Window
	glutInit(&argc, argv);										// Initialize the GLUT interface
	glutInitWindowSize(g_iWinWidth, g_iWinHeight);				// Set window to the default size
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_ALPHA);
	glutCreateWindow("NPR Rendering");

	// Set up your GLUT callbacks
	glutDisplayFunc(CB_Display);
	glutReshapeFunc(CB_Reshape);
	glutKeyboardFunc(CB_Keyboard);
	glutSpecialFunc(CB_Special);
	glutMotionFunc(CB_Motion);
	glutMouseFunc(CB_Mouse);

    // Intialize OpenGL Extensions

	// Initialize the camera
	g_Camera.mode				= CM_ORBIT;
	g_Camera.fRadius			= 1.0f;
	g_Camera.fAngle[0]			= 0.0f;
	g_Camera.fPosition[0]		= 0.0f;
	g_Camera.fPosition[1]		= 0.1f;
	g_Camera.fPosition[2]		= 0.0f;

	g_pLight.x = 90;
	g_pLight.y = 45;

	// Set up the OpenGL state
	glClearColor(0.45f, 0.5f, 0.6f, 1.0f);
	//glDisable(GL_BLEND);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glShadeModel(GL_FLAT);

    // Initialize other components
    cout << "Loading Models..." << endl;
    g_pModels[0] = LoadPolyModel("data/sphere-unit.poly");
    g_iCurrModel = 0;
    g_pNPRender = new CNPRender();

	// Enter the main GLUT loop
	g_dwLastFrame = GetTickCount();
	glutMainLoop();
	return 0;
}
