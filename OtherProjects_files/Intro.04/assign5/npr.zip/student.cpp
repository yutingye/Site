////////////////////////////////////////////////////////////////////////////////
//// Includes //////////////////////////////////////////////////////////////////
#include <cstdlib>

#include "student.h"
#include "vec.h"
#include "bmp.h"
#include "camera.h"

extern int g_iCurrModel;
extern Vec3f g_pLight;
extern CCamera g_Camera;
extern int g_outLine;
extern bool g_text;

////////////////////////////////////////////////////////////////////////////////
//// Functions /////////////////////////////////////////////////////////////////
CNPRender::CNPRender()
{
	n=0;
    Image hatch_img[4];

    LoadBMP("data/xhatch1.bmp", &hatch_img[0]);
    LoadBMP("data/xhatch2.bmp", &hatch_img[1]);
    LoadBMP("data/xhatch3.bmp", &hatch_img[2]);
    LoadBMP("data/xhatch4.bmp", &hatch_img[3]);

    // Create Texture   
    glGenTextures(4, this->hatch_tex);
    for (int i=0; i<4; ++i)
    {
		glBindTexture(GL_TEXTURE_2D, this->hatch_tex[i]);
        glTexImage2D(   GL_TEXTURE_2D, 0, 3, hatch_img[i].sizeX, hatch_img[i].sizeY, 0, 
                        GL_RGBA, GL_UNSIGNED_BYTE, hatch_img[i].pixels);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);
		glBindTexture(GL_TEXTURE_2D, 0);
		
	}
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    free(hatch_img[0].pixels);
    free(hatch_img[1].pixels);
    free(hatch_img[2].pixels);
    free(hatch_img[3].pixels);

}

void CNPRender::DrawModel(SPolyModel *model, float eye_pos[])
{
    Vec3f norm, eye, eye_dir, light, right,color;
	Vec3f vert[3];
    float dot, I;
	int index;
	float color_tex[48] = 
	{.65,.65,.15, .65,.65,.15, .65,.65,.15, .65,.65,.15, .65,.65,.15, .65,.65,.15, .65,.65,.15, .85,.85,.5, .85,.85,.5, .85,.85,.5, .85,.85,.5,  
	 .85,.85,.5, .85,.85,.5, .85,.85,.5, 1,1,1, 1,1,1};

	int tex_coord[16] = 
	{2,2,2,2,2,2,2,1,1,1,1,1,1,1,0,0};

    // Assume the view transform has already been applied
//    glColor3f(1.0f, 1.0f, 1.0f);

//   glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	if(n==0){
//		glColor3f(.5f, .5f, .5f);
		glLineWidth(1);
		glDisable(GL_CULL_FACE);
		//glCullFace(GL_BACK);
		if(g_iCurrModel == 2 || g_iCurrModel == 4)
			glPolygonMode(GL_BACK,GL_FILL);
		else
			glPolygonMode(GL_FRONT,GL_FILL);
		n=1;
	}
	else if(n==1){
		glColor3f(0.f,0.f,0.f);
		glLineWidth(g_outLine);
		glEnable(GL_CULL_FACE);
		if(g_iCurrModel == 2 || g_iCurrModel == 4){
			glCullFace(GL_BACK);
			glPolygonMode(GL_FRONT,GL_LINE);
		}
		else{
			glCullFace(GL_FRONT);
			glPolygonMode(GL_BACK, GL_LINE);
		}
		n=0;
	}

 //   glEnable(GL_TEXTURE_2D);
    glTexGenf(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
    glTexGenf(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);
//    glBindTexture(GL_TEXTURE_2D, this->hatch_tex[2]);

	eye_dir.x = cosf(DEG2RAD*(g_Camera.fAngle[0]+g_pLight.y))*sinf(DEG2RAD*(g_Camera.fAngle[1]+g_pLight.x));
	eye_dir.y = sinf(DEG2RAD*(g_Camera.fAngle[0]+g_pLight.y));
	eye_dir.z = -1.0f*cosf(DEG2RAD*(g_Camera.fAngle[0]+g_pLight.y))*cosf(DEG2RAD*(g_Camera.fAngle[1]+g_pLight.x));

	eye_dir.x = g_Camera.fRadius*eye_dir.x+ g_Camera.fPosition[0];
	eye_dir.y = g_Camera.fRadius*eye_dir.y + g_Camera.fPosition[1];
	eye_dir.z = g_Camera.fRadius*eye_dir.z + g_Camera.fPosition[2];

	eye.x = eye_pos[0];
	eye.y = eye_pos[1];
	eye.z = eye_pos[2];
	
	for (int iFace=0; iFace<model->iNumFaces; ++iFace)
	{
        memcpy(&vert[0], model->pVerts[model->pFaces[iFace].iVerts[0]].vPosition, 3*sizeof(float));
        memcpy(&vert[1], model->pVerts[model->pFaces[iFace].iVerts[1]].vPosition, 3*sizeof(float));
        memcpy(&vert[2], model->pVerts[model->pFaces[iFace].iVerts[2]].vPosition, 3*sizeof(float));

		if(n==1){
			Vec3f v1,v2,va,vb,center;

			VEC_sub2(v1,vert[0],vert[2]);
			VEC_sub2(v2,vert[1],vert[2]);
			VEC_cross(norm,v1,v2);
			VEC_Normalize(norm);

			VEC_add2(va,vert[0],vert[1]);
			VEC_scale(va,0.5);
			VEC_copy(vb,vert[2]);
			VEC_scale(va,1.0/3);
			VEC_scale(vb,2.0/3);
			VEC_add2(center,va,vb);

			light.x = center.x-eye_dir.x;
			light.y = center.y-eye_dir.y;
			light.z = center.z-eye_dir.z;

			I = 1/VEC_mag2(light);
			I = I>1?1:I;
			VEC_Normalize(light);
			dot = VEC_dot(light,norm);
			if(g_iCurrModel == 2 || g_iCurrModel == 4)
				dot = -dot;

			if(dot<0){
				index = (int)(-dot*I*16);
				color.x = color_tex[index*3];
				color.y = color_tex[index*3+1];
				color.z = color_tex[index*3+2];
				if(!g_text)
					glColor3f(color.x,color.y,color.z);
				else{
					glColor3f(1,1,1);
					glBindTexture(GL_TEXTURE_2D, this->hatch_tex[tex_coord[index]]);
				}
			}
			else{
				if(!g_text)
					glColor3f(.5,.5,0);
				else{
					glColor3f(1,1,1);
					glBindTexture(GL_TEXTURE_2D, this->hatch_tex[3]);
				}
			}
		}

		glBegin(GL_TRIANGLES);
			for(int j=0;j<3;j++)
				glVertex3fv((float *)&vert[j]);
		glEnd();
	}
}