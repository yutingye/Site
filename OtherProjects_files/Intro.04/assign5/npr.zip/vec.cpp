//=============================================================================

///////////////////////////////////////////////////////////////////////////////
//// Includes /////////////////////////////////////////////////////////////////
#include "vec.h"

///////////////////////////////////////////////////////////////////////////////
//// Functions ////////////////////////////////////////////////////////////////

/*
================
VEC_Normalize

Normalizes the given vector
===============
*/
float VEC_Normalize(Vec3f &v)
{
    float mag = 1.0f / (float)VEC_mag(v);
    v.x *= mag;
    v.y *= mag;
    v.z *= mag;
    return 1.0f / mag;
}

double VEC_Normalize(Vec3d &v)
{
    double mag = 1.0 / VEC_mag(v);
    v.x *= mag;
    v.y *= mag;
    v.z *= mag;
    return 1.0 / mag;
}

/*
================
VEC_AngToVecs

Converts the vector of spherical coordinates 'a' into the repective 
forward, up, and right vectors
===============
*/
void VEC_AngToVecs(const Vec3f &a, Vec3f &fwd, Vec3f &up, Vec3f &right)
{
    up.x = -1.0f*sinf((float)DEG2RAD*a.x)*sinf((float)DEG2RAD*a.y);
    up.y = cosf((float)DEG2RAD*a.x);
    up.z = sinf((float)DEG2RAD*a.x)*cosf((float)DEG2RAD*a.y);

    right.x = cosf((float)DEG2RAD*a.y);
    right.y = 0.0f;
    right.z = sinf((float)DEG2RAD*a.y);

    fwd.x = cosf((float)DEG2RAD*a.x)*sinf((float)DEG2RAD*a.y);
    fwd.y = sinf((float)DEG2RAD*a.x);
    fwd.z = -1.0f*cosf((float)DEG2RAD*a.x)*cosf((float)DEG2RAD*a.y);
}

void VEC_AngToVecs(const Vec3d &a, Vec3d &fwd, Vec3d &up, Vec3d &right)
{
    up.x = -1.0f*sin(DEG2RAD*a.x)*sin(DEG2RAD*a.y);
    up.y = cos(DEG2RAD*a.x);
    up.z = sin(DEG2RAD*a.x)*cos(DEG2RAD*a.y);

    right.x = cos(DEG2RAD*a.y);
    right.y = 0.0f;
    right.z = sin(DEG2RAD*a.y);

    fwd.x = cos(DEG2RAD*a.x)*sin(DEG2RAD*a.y);
    fwd.y = sin(DEG2RAD*a.x);
    fwd.z = -1.0f*cos(DEG2RAD*a.x)*cos(DEG2RAD*a.y);
}
