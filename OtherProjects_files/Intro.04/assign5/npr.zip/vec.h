#ifndef H_VEC_H
#define H_VEC_H
//=============================================================================
#define _USE_MATH_DEFINES
#include <math.h>
///////////////////////////////////////////////////////////////////////////////
//// Defines //////////////////////////////////////////////////////////////////

const float DEG2RAD = (float)M_PI/180.0f;

///////////////////////////////////////////////////////////////////////////////
//// Structures ///////////////////////////////////////////////////////////////

struct Vec3f
{
    float x;
    float y;
    float z;
};

struct Vec3d
{
    double x;
    double y;
    double z;
};

///////////////////////////////////////////////////////////////////////////////
//// Functions ////////////////////////////////////////////////////////////////

// lhs += rhs
#define VEC_add(lhs, rhs) \
    {\
        lhs.x += rhs.x; \
        lhs.y += rhs.y; \
        lhs.z += rhs.z; \
    }

#define VEC_add2(ret, lhs, rhs) \
	{\
		ret.x = lhs.x+rhs.x; \
		ret.y = lhs.y+rhs.y; \
		ret.z = lhs.z+rhs.z; \
	}

// lhs -= rhs
#define VEC_sub(lhs, rhs) \
    {\
        lhs.x -= rhs.x; \
        lhs.y -= rhs.y; \
        lhs.z -= rhs.z; \
    }

#define VEC_sub2(ret, lhs, rhs) \
	{\
		ret.x = lhs.x-rhs.x; \
		ret.y = lhs.y-rhs.y; \
		ret.z = lhs.z-rhs.z; \
	}

// lhs *= k
#define VEC_scale(lhs, k) \
    {\
        lhs.x *= k; \
        lhs.y *= k; \
        lhs.z *= k; \
    }

// lhs . rhs
#define VEC_dot(lhs, rhs) \
    ( (lhs.x*rhs.x) + (lhs.y*rhs.y) + (lhs.z*rhs.z) )

// ret = u X v
#define VEC_cross(ret, u, v) \
    { \
        ret.x = u.y*v.z - u.z*v.y; \
        ret.y = u.z*v.x - u.x*v.z; \
        ret.z = u.x*v.y - u.y*v.x; \
    }

// ||v||
#define VEC_mag(v) \
    ( sqrt(v.x*v.x + v.y*v.y + v.z*v.z) )

#define VEC_mag2(v) \
	( v.x*v.x + v.y*v.y + v.z*v.z )

// lhs = rhs
#define VEC_copy(lhs, rhs) \
    {\
        lhs.x = rhs.x; \
        lhs.y = rhs.y; \
        lhs.z = rhs.z; \
    }

float   VEC_Normalize(Vec3f &v);
double  VEC_Normalize(Vec3d &v);
void VEC_AngToVecs(const Vec3f &a, Vec3f &fwd, Vec3f &up, Vec3f &right);
void VEC_AngToVecs(const Vec3d &a, Vec3d &fwd, Vec3d &up, Vec3d &right);
//=============================================================================
#endif // Uniqueness IFNDEF
