#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <memory.h>
#include "board.h"

Board::Board( int nCol, int nRow)
{
	numCol = nCol;
	numRow = nRow;
	board = new int[nCol*nRow];
	currentBoard = new int[nCol*nRow];
	for(int i=1;i<nCol*nRow;i++)
		board[i-1] = i;
	board[i-1] = 0;
	for(i=0;i<numCol*numRow;i++)
		currentBoard[i] = board[i];
	space.col = numCol-1;
	space.row = numRow-1;
	moveList = NULL;
	numMoves = 0;
	currentMove=0;
	listLength=0;
	bSolve=false;
}

void Board::setBoard(int nCol, int nRow)
{
	if (board != NULL)
		delete []board;
	if (currentBoard != NULL)
		delete []currentBoard;
	if (moveList != NULL)
		delete []moveList;

	numCol = nCol;
	numRow = nRow;
	board = new int[nCol*nRow];
	currentBoard = new int[nCol*nRow];
	for(int i=1;i<nCol*nRow;i++)
		board[i-1] = i;
	board[i-1] = 0;
	for(i=0;i<numCol*numRow;i++)
		currentBoard[i] = board[i];
	space.col = numCol-1;
	space.row = numRow-1;
	moveList = NULL;
	numMoves = 0;
	currentMove=0;
	listLength=0;
	bSolve=false;
}

Board::~Board()
{
	if (board != NULL)
		delete []board;
	if (currentBoard != NULL)
		delete []currentBoard;
	if (moveList != NULL)
		delete []moveList;
}

inline int Board::getNumber(pos thePos)
{
	return currentBoard[numCol*thePos.row+thePos.col];
}

inline void Board::setNumber(pos thePos, int theNum)
{
	currentBoard[numCol*thePos.row+thePos.col] = theNum;
}

pos Board::getPosition(int theNum)
{
	int* p;
	for(int i=0;i<numCol*numRow;i++)
	{
		if(currentBoard[i]==theNum){
			p = &currentBoard[i];
			break;
		}
	}
	int dis = p - currentBoard;
	int row = dis/numCol;
	int col = dis%numCol;
	return pos(col, row);
}

bool Board::isNormal()
{
	int Mdis = (numCol-1 - space.col) + (numRow-1 - space.row);

	return true;
}

inline void Board::moveSpaceDown()
{
	pos Down(space.col,space.row+1);
	int num = getNumber(Down);
	setNumber(Down,0);
	setNumber(space,num);
	space.row++;
	if(bSolve)
		addMove(DOWN);
}

inline void Board::moveSpaceLeft()
{
	pos Left(space.col-1,space.row);
	int num = getNumber(Left);
	setNumber(Left,0);
	setNumber(space,num);
	space.col--;
	if(bSolve)
		addMove(LEFT);
}

inline void Board::moveSpaceRight()
{
	pos Right(space.col+1,space.row);
	int num = getNumber(Right);
	setNumber(Right,0);
	setNumber(space,num);
	space.col++;
	if(bSolve)
		addMove(RIGHT);
}

inline void Board::moveSpaceUp()
{
	pos Up(space.col, space.row-1);
	int num = getNumber(Up);
	setNumber(Up,0);
	setNumber(space,num);
	space.row--;
	if(bSolve)
		addMove(UP);
}

void Board::moveT(int theNum, int dir)
{//assume space is to the U/D/L/R of the number
	pos n = getPosition(theNum);
	if(n.col == space.col){
		if(n.row>space.row){ //space is UP
			switch(dir){
			case UP:
				moveSpaceDown();
				break;
			case DOWN:
				if(space.col<numCol-1){
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceUp();
				}
				else{
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceUp();
				}
				break;
			case LEFT:
				moveSpaceLeft();
				moveSpaceDown();
				moveSpaceRight();
				break;
			case RIGHT:
				moveSpaceRight();
				moveSpaceDown();
				moveSpaceLeft();
				break;
			}
		}
		else if (n.row<space.row){ //space is DOWN
			switch(dir){
			case UP:
				if(space.col<numCol-1){
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceDown();
				}
				else{
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceDown();
				}
				break;
			case DOWN:
				moveSpaceUp();
				break;
			case LEFT:
				moveSpaceLeft();
				moveSpaceUp();
				moveSpaceRight();
				break;
			case RIGHT:
				moveSpaceRight();
				moveSpaceUp();
				moveSpaceLeft();
				break;
			}
		}
	}
	else if(n.row == space.row){
		if(n.col<space.col){ //space is RIGHT
			switch(dir){
			case UP:
				moveSpaceUp();
				moveSpaceLeft();
				moveSpaceDown();
				break;
			case DOWN:
				moveSpaceDown();
				moveSpaceLeft();
				moveSpaceUp();
				break;
			case LEFT:
				if(space.row<numRow-1){
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceRight();
				}
				else{
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceRight();
				}
				break;
			case RIGHT:
				moveSpaceLeft();
				break;
			}
		}
		else if(n.col>space.col){ //space is LEFT
			switch(dir){
			case UP:
				if(n.col<numCol-1&&n.row<numRow-1){
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceDown();
				}
				else{
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceDown();
				}
				break;
			case DOWN:
				moveSpaceDown();
				moveSpaceRight();
				moveSpaceUp();
				break;
			case LEFT:
				moveSpaceRight();
				break;
			case RIGHT:
				if(space.row<numRow-1){
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceLeft();
				}
				else{
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceLeft();
				}
				break;
			}
		}
	}

}

void Board::moveD(int theNum, int dirH, int dirV)
{
	pos n = getPosition(theNum);
	if(n.col == space.col){
		if(n.row > space.row){ //space is UP
			if(dirV == UP){
				if(dirH == LEFT){ //move UP-LEFT
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceRight();
				}
				else if(dirH == RIGHT){ //move UP-RIGHT
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceLeft();
				}
			}
			else if(dirV == DOWN){
				if(dirH == LEFT){ // move DOWN-LEFT
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceUp();
				}
				else if(dirH == RIGHT){ // move DOWN-RIGHT
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceUp();
				}
			}
		}
		else if (n.row < space.row){ // space is DOWN
			if(dirV == UP){
				if(dirH == LEFT){ //move UP-LEFT
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceDown();
				}
				else if(dirH == RIGHT){ //move UP-RIGHT
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceDown();
				}
			}
			else if(dirV == DOWN){
				if(dirH == LEFT){ // move DOWN-LEFT
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceRight();
				}
				else if(dirH == RIGHT){ // move DOWN-RIGHT
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceLeft();
				}
			}
		}
	}
	else if(n.row == space.row){
		if(n.col<space.col){ //space is RIGHT
			if(dirV == UP){
				if(dirH == LEFT){ //move UP-LEFT
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceRight();
				}
				else if(dirH == RIGHT){ //move UP-RIGHT
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceDown();
				}
			}
			else if(dirV == DOWN){
				if(dirH == LEFT){ //move DOWN-LEFT
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceRight();
				}
				else if(dirH == RIGHT){ //move DOWN-RIGHT
					moveSpaceLeft();
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceUp();
				}
			}
		}
		else if (n.col>space.col){ //space is LEFT
			if(dirV == UP){
				if(dirH == LEFT){ //move UP-LEFT
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceLeft();
					moveSpaceDown();
				}
				else if(dirH == RIGHT){ //move UP-RIGHT
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceLeft();
				}
			}
			else if(dirV == DOWN){
				if(dirH == LEFT){ //move DOWN-LEFT
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceLeft();
					moveSpaceUp();
				}
				else if(dirH == RIGHT){ //move DOWN-RIGHT
					moveSpaceDown();
					moveSpaceRight();
					moveSpaceUp();
					moveSpaceRight();
					moveSpaceDown();
					moveSpaceLeft();
				}
			}
		}
	}
}

void Board::moveSpace(pos destPos)
{
	int i;
	int disCol = abs(destPos.col - space.col);
	int disRow = abs(destPos.row - space.row);
	if(destPos.col > space.col){
		for(i=0;i<disCol;i++)
			moveSpaceRight();
	}
	if(destPos.row >space.row){
		for(i=0;i<disRow;i++)
			moveSpaceDown();
	}
	if(destPos.col < space.col){
		for(i=0;i<disCol;i++)
			moveSpaceLeft();
	}
	if(destPos.row < space.row){
		for(i=0;i<disRow;i++)
			moveSpaceUp();
	}
}

void Board::printBoard()
{
	int i,j;
	for(i=0;i<numRow;i++){
		for(j=0; j<numCol; j++){
			printf("%d   ",currentBoard[numCol*i+j]); 
		}
		printf("\n");
	}
	printf("Space:(%d,%d)\n",space.col,space.row);
	printf("\n");
}

void Board::Scramble(int steps)
{
	bSolve=false;
	numMoves = currentMove=0;
	//srand(rand()*rand());
	for(int i=0; i<steps; i++)
	{
		int dir = rand()%4;
		switch(dir){
		case UP:
			if(space.row > 0)
				moveSpaceUp();
			else
				i--;
			break;
		case DOWN:
			if(space.row<numRow-1)
				moveSpaceDown();
			else
				i--;
			break;
		case LEFT:
			if(space.col>0)
				moveSpaceLeft();
			else
				i--;
			break;
		case RIGHT:
			if(space.col<numCol-1)
				moveSpaceRight();
			else
				i--;
			break;
		}
	}
	for(i=0;i<numRow*numCol;i++)
		board[i]=currentBoard[i];
}

void Board::move(int target, pos destPos)
{//assume space is near it (to the U/D/L/R)
//do not disturb the ordered cells
	int dist;
	pos tPos = getPosition(target);
	//move diagonally to the right column or row
	//then move up or horizonal to the right place
	if(tPos.row == destPos.row){//on the home row
		if(tPos.col<destPos.col){//to the left, move right
			dist = destPos.col - tPos.col;
			while(dist--)
				moveT(target,RIGHT);
		}
		else if(tPos.col>destPos.col){//to the right, move left
			dist = tPos.col - destPos.col;
			while(dist--)
				moveT(target,LEFT);
		}
	}
	else{
		if(tPos.col<destPos.col){//to the left of the home column
			while(tPos.row>destPos.row+1 && tPos.col<destPos.col){ 
				moveD(target,RIGHT,UP);
				tPos.col++;
				tPos.row--;
			}
			if(tPos.col==destPos.col){//on the home column, move up
				if(tPos.row>destPos.row){
					dist = tPos.row-destPos.row;
					while(dist--)
						moveT(target,UP);
				}
				else if(tPos.row<destPos.row){
					dist = destPos.row - tPos.row;
					while(dist--)
						moveT(target,DOWN);
				}
			}
			else if(tPos.row==destPos.row+1){//on the home row, move right, then up as the last move
				dist = destPos.col-tPos.col;
				while(dist--)
					moveT(target,RIGHT);
				moveT(target,UP);
			}
		}
		else if(tPos.col>destPos.col){ //to the right of the home column
			if(tPos.row>destPos.row){
				while(tPos.row>destPos.row && tPos.col>destPos.col){
					moveD(target,LEFT,UP);
					tPos.col--;
					tPos.row--;
				}
			}
			else if(tPos.row<destPos.row){
				while(tPos.row<destPos.row && tPos.col>destPos.col){
					moveD(target,LEFT,DOWN);
					tPos.col--;
					tPos.row++;
				}
			}
			if(tPos.col==destPos.col){ //on the home column, move up
				if(tPos.row>destPos.row){
					dist = tPos.row - destPos.row;
					while(dist--)
						moveT(target,UP);
				}
				else if(tPos.row<destPos.row){
					dist=destPos.row - tPos.row;
					while(dist--)
						moveT(target,DOWN);
				}
			}
			else if(tPos.row==destPos.row){//on the home row, move left, then up as the last move 
				dist = tPos.col - destPos.col;
				while(dist--)
					moveT(target,LEFT);
			}
		}
		else{ // on the home column, move up directly
			if(tPos.row>destPos.row){
				dist = tPos.row - destPos.row;
				while(dist--)
					moveT(target,UP);
			}
			else if(tPos.row<destPos.row){
				dist = destPos.row - tPos.row;
				while(dist--)
					moveT(target,DOWN);
			}
		}
	}
}

void Board::moveSpaceAroundTarget(pos tPos)
{
	//move space near the target, not disturbing the ordered numbers			
	if(space.col<tPos.col) //move to target's left
		moveSpace(pos(tPos.col-1,tPos.row));
	else if(space.col>tPos.col) //move to target's right
		moveSpace(pos(tPos.col+1,tPos.row));
	else{ //if on the same column
		if(space.row<tPos.row) //move to UP
			moveSpace(pos(tPos.col,tPos.row-1));
		else if(space.row>tPos.row) //move to DOWN
			moveSpace(pos(tPos.col,tPos.row+1));
	}
}

void Board::solve()
{
	int i,j;
	int target;
	pos tPos;
	bSolve=true;
	if(listLength==0)
	{
		listLength=100;
		moveList=new int[listLength];
	}
	for(i=0;i<numRow-1;i++){
		if(i<numRow-2){
			for(j=0;j<numCol-1;j++){
				target = i*numCol+j+1;
				if(j<numCol-2){//getNumber(pos(j,i))!=target)
						//if not the last 2 columns, move target to the right place directly
					if(getNumber(pos(j,i))!=target){
						tPos = getPosition(target);
						moveSpaceAroundTarget(tPos);
						move(target, pos(j,i));
					}
					printBoard();
				}
				else if(getNumber(pos(j,i))!=target || getNumber(pos(j+1,i))!=target+1)
				{ //if target is not on the right place
					tPos = getPosition(target);
					moveSpaceAroundTarget(tPos);
					printBoard();
					move(target, pos(j+1,i));
					printBoard();
					if(getNumber(pos(j,i))==target+1){//the special case
						moveSpaceLeft();
						moveSpaceUp();
						moveSpaceRight();
						moveSpaceDown();
						moveSpaceDown();
						moveSpaceLeft();
						moveSpaceUp();
						moveSpaceRight();
						moveSpaceUp();
						moveSpaceLeft();
					}
					else if(space.col==j&&space.row==i&&getNumber(pos(j,i+1))==target+1){
						moveSpaceRight();
						moveSpaceDown();
						moveSpaceDown();
						moveSpaceLeft();
						moveSpaceUp();
						moveSpaceRight();
						moveSpaceUp();
						moveSpaceLeft();
					}
					printBoard();
					moveSpaceAroundTarget(getPosition(target+1));
					printBoard();
					move(target+1,pos(j+1,i+1));
					
					printBoard();
					moveSpace(pos(j,i));
					printBoard();
					moveSpaceRight();
					moveSpaceDown();
					printBoard();
				}//end if(the last 2 columns)

			}//end for j
		}//end if(not the last 2 rows) 
		else{//the last 2 rows
			for(j=0;j<numCol-1;j++){
				target = i*numCol+j+1;
				if(getNumber(pos(j,i))!=target || getNumber(pos(j,i+1))!=(i+1)*numCol+j+1){//things not right
					tPos = getPosition(target);
					moveSpaceAroundTarget(tPos);
					printBoard();
					move(target,pos(j,i+1));
					printBoard();
					int t2 = (i+1)*numCol+j+1;

					if(getNumber(pos(j,i))==t2){
						moveSpaceUp();
						moveSpaceLeft();
						moveSpaceDown();
						moveSpaceRight();
						moveSpaceRight();
						moveSpaceUp();
						moveSpaceLeft();
						moveSpaceDown();
						moveSpaceLeft();
						moveSpaceUp();
					}
					else if(space.col==j&&space.row==i&&getNumber(pos(j+1,i))==t2){
						moveSpaceDown();
						moveSpaceRight();
						moveSpaceRight();
						moveSpaceUp();
						moveSpaceLeft();
						moveSpaceDown();
						moveSpaceLeft();
						moveSpaceUp();
					}
					printBoard();
					moveSpaceAroundTarget(getPosition(t2));
					printBoard();
					move(t2,pos(j+1,i+1));

					printBoard();
					moveSpace(pos(space.col,i));
					moveSpace(pos(j,i));
					printBoard();
					moveSpaceDown();
					moveSpaceRight();
				}
			}//end j
//the last 2X2 square
			if(space.row!=numRow-1)
				moveSpaceDown();
		}//end if(the last 2 rows)
	}//end for i
	printBoard();
	for(i=0;i<numCol*numRow;i++)
		currentBoard[i] = board[i];
	space=getPosition(0);
	bSolve=false;
}

void Board::addMove(int theMove)
{
	if(numMoves==listLength-1){
		int* temp=new int[listLength+50];
		memcpy(temp, moveList, sizeof(int)*listLength);
		delete []moveList;
		moveList = temp;
		moveList[numMoves++]=theMove;
		listLength+=50;
	}
	else
		moveList[numMoves++]=theMove;
}

void Board::playMove()
{
	if(currentMove<numMoves){
		switch(moveList[currentMove])
		{
		case UP:
			moveSpaceUp();
			break;
		case DOWN:
			moveSpaceDown();
			break;
		case LEFT:
			moveSpaceLeft();
			break;
		case RIGHT:
			moveSpaceRight();
			break;
		}
		currentMove++;
	}
}