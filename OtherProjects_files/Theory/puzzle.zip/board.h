#ifndef _BOARD_H
#define _BOARD_H

struct pos
{
	pos(int c=0, int r=0): col(c), row(r){}
	int col;
	int row;
};

enum {LEFT, RIGHT, DOWN, UP};

class Board
{
public:
	int* board;
	int* moveList;
	int numMoves;
	int currentMove;
	int listLength;
	bool bSolve;
	int* currentBoard;
	pos space;

public:
	int numCol;
	int numRow;
	Board( int nCol, int nRow);
	~Board();
	bool isNormal();
	pos getPosition(int theNum );
	inline int getNumber(pos thePos);
	inline void setNumber( pos thePos, int theNum);
	void Scramble(int steps);
	void setBoard(int nCol, int nRow);
	void moveSpace( pos destPos);
	inline void moveSpaceUp();
	inline void moveSpaceDown();
	inline void moveSpaceLeft();
	inline void moveSpaceRight();
	void moveSpaceAroundTarget(pos target);
	void moveT( int theNum, int dir );
	void moveD( int theNum, int dirH, int dirV);
	void move(int theNum, pos destPos);
	void printBoard();
	void addMove(int theMove);
	void playMove();
	void solve();
};

#endif