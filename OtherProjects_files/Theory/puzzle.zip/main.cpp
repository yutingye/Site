#include "board.h"
#include "gui.h"

MyBoard* b;
Board* theBoard;
bool bPlay;

void timeOut(void*)
{
	if(bPlay){
		theBoard->playMove();
		b->redraw();
		if(theBoard->currentMove==theBoard->numMoves)
			bPlay=false;
	}
	Fl::repeat_timeout(0.2, timeOut);
}

int main(int argc, char **argv) 
{
	bPlay=false;
	Fl_Window* w = make_window();
	b=new MyBoard(10,10,605,605);
	w->end();
	w->show();

	theBoard = new Board(b->col,b->row);

	Fl::add_timeout(0.2, timeOut);
	return Fl::run();
}