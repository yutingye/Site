function [O] = grey(I)
 
  [In] = RGB2Yxy(I);
  Lum = In(:,:,1);
%In=RGB2Lab(I);
%Lum = In(:,:,1);
 subplot(2,3,1),imshow(I);
 subplot(2,3,3),imhist(Lum);
 subplot(2,3,2),imshow(Lum);
 nLum = Scale2Midtone(Lum);
 [C fC] = ChromaDiff(In);
 %CompConv();
 O = toneMap(nLum,C,fC);
 subplot(2,3,6),imhist(O);
 subplot(2,3,5),imshow(O);
 %O = O*100;
 Clamp(O);
 In(:,:,1)=O;
 imwrite(O,'GreyResult.bmp');
O = Yxy2RGB(In);
% In(:,:,1)=O;
%  O = Lab2RGB(In);
 subplot(2,3,4),imshow(O);
 
 function  [O] = RGB2Yxy(I)
     const = [0.5141364 0.3238786 0.16036376;
			  0.265068  0.67023428 0.06409157;
			  0.0241188 0.1228178 0.84442666];
     [maxX maxY n] = size(I);
     for i=1:maxX
         for j = 1:maxY
             temp(1:3) = I(i,j,1:3);
             result = const * double(temp');
             W = result(1)+result(2)+result(3);
             if(W>0)
                 O(i,j,1)=result(2)/255;
                 O(i,j,2)=result(1)/W;
                 O(i,j,3)=result(2)/W;
             else
                 O(i,j,1:3)=0;
             end;
         end;
     end;
     
 function [O] = Yxy2RGB(I)
     const = [ 2.5651  -1.1665  -0.3986;
              -1.0217   1.9777   0.0439;
               0.0753  -0.2543   1.1892];
    [x y n] = size(I);
    for i=1:x
        for j=1:y
            Y = I(i,j,1);
            result(2)=I(i,j,2);
            result(3)=I(i,j,3);
            if(Y>0 && result(2)>0 && result(3)>0)
                X = result(2)*Y/result(3);
                Z = (X/result(2)) - X - Y;
            else
                X = 0;
                Z = 0;
            end;
            result = const*[X; Y; Z];
            O(i,j,:)=result';
        end;
    end;
                
 function Clamp(L)
     [x y] = size(L);
     for i= 1:x
         for j=1:y
             if(L(x,y)>1)
                 L(x,y)=1;
             end;
         end;
     end;
 
 function [nLum] = Scale2Midtone(Lum)
     [maxX maxY] = size(Lum);
     scaleFactor = exp(sum(sum(log(Lum+0.00001)))/(maxX*maxY));
     nLum = Lum.*(.18/scaleFactor);
     
 function [nLum] = toneMap(Lum,C,fC)
     maxL = max(Lum(:));
     maxL = maxL*maxL;
     maxC = max(abs(fC(:)-C(:)));
     %maxC = maxC*maxC;
     gfilter = fspecial('gaussian',[17 17], .5);
     t = filter2(gfilter,Lum);
%     [x y] = size(Lum);
%     for i=1:x
%         for j=1:y
%             if(Lum(i,j)>t(i,j))
%                 nLum(i,j) = (Lum(i,j)+(C(i,j)-fC(i,j))*(fC(i,j)/C(i,j))+(Lum(i,j)*Lum(i,j)/maxL))/(t(i,j)+1);
%             else
%                 nLum(i,j) = (Lum(i,j)+(fC(i,j)-C(i,j))*(fC(i,j)/C(i,j))+(Lum(i,j)*Lum(i,j)/maxL))/(t(i,j)+1);
%             end;
%         end;
 %    end;
     nLum = (Lum+(fC-C)+(Lum.*Lum)./maxL)./(t+1+fC);%
 %    dC = abs(C - fChroma);
 %    dL = abs(Lum - t);
 %    [x y] = size(Lum);
 %    for i=1:x
 %        for j=1:y
 %            if(dC>dL)
 %               nLum(i,j) = (C(i,j))/(C(i,j)+1);%+(C(i,j)*C(i,j))/maxC
 %            else
 %               nLum(i,j) = (Lum(i,j)+(Lum(i,j)*Lum(i,j))/maxL)/(1+t(i,j));
 %            end;
 %        end;
 %    end;
             
     %nLum = (Lum+1)./(Lum+);
    
 function [C fC] = ChromaDiff(I)
     a=I(:,:,2)-1/3;
     b=I(:,:,3)-1/3;
     fC = sqrt(a.*a+b.*b);
     [x y] = size(I);
     gfilter = fspecial('log',[7 7],0.6);
     C = filter2(gfilter,fC);
