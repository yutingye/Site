function [O] = newGrey(I)
 
subplot(2,3,1),imshow(I),title 'original image'
key = 0.18;
gamma = 1.0;
[Img] = RGB2Yxy(double(I)./255);
%Img = RGB2Lab(I);
Lum = Img(:,:,1);
subplot(2,3,2),imshow(Lum),title 'original luminance'
subplot(2,3,3),imhist(Lum),title 'histogram'
Chroma = ((Img(:,:,2)-1/3).^2+(Img(:,:,3)-1/3).^2);

% nLum = Scale2Midtone(Lum);
[x y] = size(Lum);
scaleFactor = exp(sum(sum(log(Lum+0.00001)))/(x*y));
Lum = Lum.*(key/scaleFactor);

%fLum = CompConv(nLum);
for s = 1:4
    sigma = (1.6^s)*0.35/(sqrt(2));
    gfilter = fspecial('gaussian',[x y], sigma);
    %lfilter = fspecial('gaussian',[x y], sigma);
    fLum(s,:,:) = filter2(gfilter,Lum);
    fChr(s,:,:) = filter2(gfilter,Chroma);
    %lChr(s,:,:) = lChr(s,:,:)*20;
end;
%max(lChr(:,:,:));
mL = max(Lum(:))
mC = max(Chroma(:))
Chroma = Chroma*mL/mC;
fChr = fChr*mL/mC;

% O = toneMap(nLum,fLum);
maxL = max(Lum(:));
maxL = maxL*maxL;
const = key*(2^8.0);
for i=1:x
 for j=1:y
     for s=1:3
         diff = (fLum(s+1,i,j)-fLum(s,i,j))/(const/(1.6^(2*s))+fLum(s,i,j));
         %
         %diff = (fChr(s+1,i,j)-fChr(s,i,j))/(const/(1.6^(2*s))+fChr(s,i,j));
         if(abs(diff)>0.05)
             break;
         end;
     end;
     O(i,j) = (Lum(i,j)+Chroma(i,j)+Lum(i,j).*Lum(i,j)/maxL)/(1+fChr(s,i,j)+fLum(s,i,j));%
     L(i,j) = (Lum(i,j)+Lum(i,j).*Lum(i,j)/maxL)/(1+fLum(s,i,j));
 end;
end;

Img(:,:,1)=O;
O = Yxy2RGB(Img);
%O = Lab2RGB(Img);
Clamp(O);
O = 255*(O.^(1.0/gamma));
O = (real(O));
subplot(2,3,4),imshow(L),title 'contrast enhance'
I = RGB2Yxy(O./255);
%I = RGB2Lab(O);
subplot(2,3,5),imshow(I(:,:,1)),title 'new luminance'
subplot(2,3,6),imhist(I(:,:,1)),title 'histogram'
imwrite(I(:,:,1),'result.bmp');
 
 function  [O] = RGB2Yxy(I)
     const = [0.5141364 0.3238786 0.16036376;
			  0.265068  0.67023428 0.06409157;
			  0.0241188 0.1228178 0.84442666];
    %  const = [0.488718 0.176204 0.000000;
    %           0.310680 0.812985 0.0102048;
    %           0.200602 0.0108109 0.989795];
     [maxX maxY n] = size(I);
     for i=1:maxX
         for j = 1:maxY
             temp(1:3) = I(i,j,1:3);
             result = const * double(temp');
             W = result(1)+result(2)+result(3);
             if(W>0)
                 O(i,j,1)=result(2);
                 O(i,j,2)=result(1)/W;
                 O(i,j,3)=result(2)/W;
             else
                 O(i,j,1:3)=0;
             end;
         end;
     end;
     
 function [O] = Yxy2RGB(I)
     const = [ 2.5651  -1.1665  -0.3986;
              -1.0217   1.9777   0.0439;
               0.0753  -0.2543   1.1892];
     %const = [ 2.37067  -0.513885  0.00529818;
     %          -0.900040 1.42530  -0.0146949;
     %          -0.470634 0.0885814 1.00940 ];
    [x y n] = size(I);
    for i=1:x
        for j=1:y
            Y = I(i,j,1);
            result(2)=I(i,j,2);
            result(3)=I(i,j,3);
            if(Y>0 && result(2)>0 && result(3)>0)
                X = result(2)*Y/result(3);
                Z = (X/result(2)) - X - Y;
            else
                X = 0;
                Z = 0;
            end;
            result = const*[X; Y; Z];
            O(i,j,:)=result';
        end;
    end;
                
 function Clamp(L)
     [x y n] = size(L);
     for i= 1:x
         for j=1:y
             if(L(i,j)>1)
                 L(i,j)=1;
             end;
%             if(L(i,j,2)>1)
%                 L(i,j,2)=1;
%             end;
%             if(L(i,j,3)>1)
%                 L(i,j,3)=1;
%             end;
         end;
     end;
 
 function [nLum] = Scale2Midtone(Lum)
     [maxX maxY] = size(Lum);
     scaleFactor = exp(sum(sum(log(Lum+0.00001)))/(maxX*maxY));
     nLum = Lum.*(0.18/scaleFactor);
     
 function [nLum] = toneMap(Lum,fLum)
     maxL = max(Lum(:));
     maxL = maxL*maxL;
     const = 0.18*(2^8.0);
     [x y] = size(Lum);
     for i=1:x
         for j=1:y
             for s=1:3
                 diff = (fLum(s+1,i,j)-fLum(s,i,j))/(const/(1.6^(2*s))+fLum(s,i,j));
                 if(abs(diff)>0.05)
                     break;
                 end;
             end;
             nLum(i,j) = (Lum(i,j)*(1+Lum(i,j)/maxL))/(1.0+fLum(s,i,j));
         end;
     end;
     
function [fLum] = CompConv(nLum)
    [x y] = size(nLum);
    for s = 1:4
        sigma = (1.6^s)*0.35/(sqrt(2));
        gfilter = fspecial('gaussian',[x y], sigma);
        fLum(s,:,:) = filter2(gfilter,nLum);
    end;